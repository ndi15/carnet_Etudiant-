import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'

export async function POST(request) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) {
    return NextResponse.json({ error: 'Non connecté' }, { status: 401 })
  }

  const { url } = await request.json()
  if (!url) {
    return NextResponse.json({ error: 'URL manquante' }, { status: 400 })
  }

  let icsText
  try {
    const res = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; CarnetEtudiant/1.0; +calendar-sync)',
        'Accept': 'text/calendar, text/plain, */*',
      },
      redirect: 'follow',
    })
    if (!res.ok) throw new Error(`Statut HTTP ${res.status}`)
    icsText = await res.text()
    if (!icsText.includes('BEGIN:VCALENDAR')) {
      throw new Error('La réponse ne ressemble pas à un calendrier .ics valide')
    }
  } catch (e) {
    return NextResponse.json({ error: `Impossible d'accéder à cette URL (${e.message}). Vérifie qu'elle est correcte et accessible sans connexion préalable.` }, { status: 400 })
  }

  // Parsing simple des événements VEVENT
  const lines = icsText.split(/\r?\n/)
  const events = []
  let cur = {}
  for (const line of lines) {
    if (line.startsWith('BEGIN:VEVENT')) cur = {}
    if (line.startsWith('SUMMARY:')) cur.title = line.replace('SUMMARY:', '').trim()
    if (line.startsWith('DTSTART')) {
      const raw = line.split(':')[1]?.trim()
      if (raw) {
        const y = raw.slice(0, 4), m = raw.slice(4, 6), d = raw.slice(6, 8)
        cur.date = `${y}-${m}-${d}`
        if (raw.includes('T') && raw.length >= 13) {
          cur.start_time = `${raw.slice(9, 11)}:${raw.slice(11, 13)}`
        }
      }
    }
    if (line.startsWith('DTEND')) {
      const raw = line.split(':')[1]?.trim()
      if (raw && raw.includes('T') && raw.length >= 13) {
        cur.end_time = `${raw.slice(9, 11)}:${raw.slice(11, 13)}`
      }
    }
    if (line.startsWith('END:VEVENT') && cur.title) {
      events.push({ title: cur.title, event_date: cur.date || null, start_time: cur.start_time || null, end_time: cur.end_time || null, user_id: user.id })
      cur = {}
    }
  }

  if (events.length === 0) {
    return NextResponse.json({ error: "Aucun événement trouvé dans ce calendrier." }, { status: 400 })
  }

  // On supprime les anciens événements importés automatiquement, puis on réimporte à jour
  await supabase.from('events').delete().eq('user_id', user.id).eq('source', 'sync')
  const { data, error } = await supabase
    .from('events')
    .insert(events.map((e) => ({ ...e, source: 'sync' })))
    .select()

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  // On sauvegarde l'URL pour pouvoir resynchroniser plus tard
  await supabase.from('hour_counter_settings').update({ university_calendar_url: url }).eq('user_id', user.id)

  return NextResponse.json({ events: data })
}
