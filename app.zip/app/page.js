'use client'

import React, { useState, useEffect, useMemo, useCallback } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Clock, Briefcase, BookOpen, CalendarDays, Plus, Trash2, Upload, Menu, X, LogOut, Link2, ExternalLink } from "lucide-react";

const DAYS = ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"];
const DAYS_FULL = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
const INK = "#14162B";
const PAPER = "#F2F3ED";
const MARKER = "#FFC857";
const TEAL = "#1FA97F";

function toMinutes(hhmm) {
  const [h, m] = hhmm.split(":").map(Number);
  return h * 60 + m;
}

function fmtHours(mins) {
  const sign = mins < 0 ? "-" : "";
  const abs = Math.abs(mins);
  const h = Math.floor(abs / 60);
  const m = Math.round(abs % 60);
  return `${sign}${h}h${m.toString().padStart(2, "0")}`;
}

function weeklyScheduledMinutes(shifts) {
  return shifts.reduce((sum, s) => sum + (toMinutes(s.end_time) - toMinutes(s.start_time)), 0);
}

function projectQuotaDate(remainingMin, shifts, now) {
  const weeklyMin = weeklyScheduledMinutes(shifts);
  if (weeklyMin <= 0) return null;
  const weeksNeeded = remainingMin / weeklyMin;
  const projected = new Date(now);
  projected.setDate(projected.getDate() + Math.ceil(weeksNeeded * 7));
  return projected;
}

function fmtRelativeDate(dateStr, now) {
  if (!dateStr) return "";
  const target = new Date(dateStr + "T00:00:00");
  const diffMs = target - now;
  const diffHours = diffMs / (1000 * 60 * 60);
  if (diffHours < 0) return new Date(dateStr).toLocaleDateString("fr-FR");
  if (diffHours < 24) return `dans ${Math.max(1, Math.round(diffHours))}h`;
  const diffDays = Math.round(diffHours / 24);
  if (diffDays === 1) return "demain";
  if (diffDays <= 14) return `dans ${diffDays} jours`;
  return new Date(dateStr).toLocaleDateString("fr-FR");
}

function computeWorkedMinutes(shifts, startDate, now, manualHours = []) {
  let total = 0;
  const start = new Date(startDate);
  start.setHours(0, 0, 0, 0);
  const end = new Date(now);
  end.setHours(0, 0, 0, 0);

  if (shifts.length) {
    const cursor = new Date(start);
    while (cursor <= end) {
      const dow = cursor.getDay();
      const isToday = cursor.getTime() === end.getTime();
      shifts.forEach((s) => {
        if (s.day_of_week !== dow) return;
        const startM = toMinutes(s.start_time);
        const endM = toMinutes(s.end_time);
        if (isToday) {
          const nowM = now.getHours() * 60 + now.getMinutes();
          if (nowM > startM) total += Math.min(nowM, endM) - startM;
        } else {
          total += endM - startM;
        }
      });
      cursor.setDate(cursor.getDate() + 1);
    }
  }

  manualHours.forEach((m) => {
    const d = new Date(m.entry_date + "T00:00:00");
    if (d >= start && d <= end) total += m.minutes;
  });

  return Math.max(0, total);
}

export default function Home() {
  const supabase = createClient();
  const router = useRouter();

  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("planning");
  const [menuOpen, setMenuOpen] = useState(false);
  const [openGroup, setOpenGroup] = useState("MON TRAVAIL");

  const [shifts, setShifts] = useState([]);
  const [contracts, setContracts] = useState([]);
  const [counterSettings, setCounterSettings] = useState({ start_date: new Date().toISOString().slice(0, 10) });
  const [courses, setCourses] = useState([]);
  const [homework, setHomework] = useState([]);
  const [events, setEvents] = useState([]);
  const [links, setLinks] = useState([]);
  const [courseDocuments, setCourseDocuments] = useState([]);
  const [chapters, setChapters] = useState([]);
  const [personalTasks, setPersonalTasks] = useState([]);
  const [chapterDocuments, setChapterDocuments] = useState([]);
  const [feedback, setFeedback] = useState([]);
  const [manualHours, setManualHours] = useState([]);
  const [personalDocuments, setPersonalDocuments] = useState([]);
  const ANNUAL_QUOTA_HOURS = 964;

  // Chargement initial de toutes les données depuis Supabase
  useEffect(() => {
    async function loadAll() {
      const [{ data: shiftsData }, { data: contractsData }, { data: counterData }, { data: coursesData }, { data: homeworkData }, { data: eventsData }, { data: linksData }, { data: docsData }, { data: chaptersData }, { data: tasksData }, { data: chapterDocsData }, { data: feedbackData }, { data: manualData }, { data: personalDocsData }] =
        await Promise.all([
          supabase.from("shifts").select("*"),
          supabase.from("contracts").select("*").order("created_at", { ascending: false }),
          supabase.from("hour_counter_settings").select("*").maybeSingle(),
          supabase.from("courses").select("*"),
          supabase.from("homework").select("*"),
          supabase.from("events").select("*"),
          supabase.from("important_links").select("*").order("created_at", { ascending: false }),
          supabase.from("course_documents").select("*").order("created_at", { ascending: true }),
          supabase.from("chapters").select("*").order("created_at", { ascending: true }),
          supabase.from("personal_tasks").select("*").order("task_date", { ascending: true }),
          supabase.from("chapter_documents").select("*").order("created_at", { ascending: true }),
          supabase.from("feedback").select("*").order("created_at", { ascending: false }),
          supabase.from("manual_hours").select("*").order("entry_date", { ascending: false }),
          supabase.from("personal_documents").select("*").order("created_at", { ascending: false }),
        ]);

      if (shiftsData) setShifts(shiftsData);
      if (contractsData) setContracts(contractsData);
      if (counterData) setCounterSettings(counterData);
      if (coursesData) setCourses(coursesData);
      if (homeworkData) setHomework(homeworkData);
      if (eventsData) setEvents(eventsData);
      if (linksData) setLinks(linksData);
      if (docsData) setCourseDocuments(docsData);
      if (chaptersData) setChapters(chaptersData);
      if (tasksData) setPersonalTasks(tasksData);
      if (chapterDocsData) setChapterDocuments(chapterDocsData);
      if (feedbackData) setFeedback(feedbackData);
      if (manualData) setManualHours(manualData);
      if (personalDocsData) setPersonalDocuments(personalDocsData);
      setLoading(false);
    }
    loadAll();
  }, []);

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push("/login");
    router.refresh();
  }

  // --- Shifts ---
  async function addShift(shift) {
    const { data: { user } } = await supabase.auth.getUser();
    const { data, error } = await supabase
      .from("shifts")
      .insert({ ...shift, user_id: user.id })
      .select()
      .single();
    if (!error && data) setShifts((p) => [...p, data]);
  }
  async function removeShift(id) {
    await supabase.from("shifts").delete().eq("id", id);
    setShifts((p) => p.filter((s) => s.id !== id));
  }

  // --- Compteur (date de départ) ---
  async function updateStartDate(date) {
    const { data: { user } } = await supabase.auth.getUser();
    const { data, error } = await supabase
      .from("hour_counter_settings")
      .upsert({ ...counterSettings, user_id: user.id, start_date: date }, { onConflict: "user_id" })
      .select()
      .single();
    if (!error && data) setCounterSettings(data);
    else setCounterSettings((p) => ({ ...p, start_date: date }));
  }

  // --- Contrats (plusieurs possibles) ---
  async function addContract({ name, signed_date, hourly_rate, file }) {
    const { data: { user } } = await supabase.auth.getUser();
    const { data: inserted, error } = await supabase
      .from("contracts")
      .insert({
        employer: name,
        signed_date: signed_date || null,
        hourly_rate: hourly_rate === "" || hourly_rate == null ? null : parseFloat(hourly_rate),
        user_id: user.id,
      })
      .select()
      .single();
    if (error || !inserted) {
      console.error("Erreur création contrat:", error);
      return;
    }

    if (!file) {
      setContracts((p) => [inserted, ...p]);
      return;
    }

    const path = `${user.id}/${inserted.id}-${file.name}`;
    const { error: uploadError } = await supabase.storage.from("contracts").upload(path, file);
    if (uploadError) {
      console.error("Erreur upload fichier contrat:", uploadError);
      setContracts((p) => [inserted, ...p]);
      return;
    }

    const { data: updated, error: updateError } = await supabase
      .from("contracts")
      .update({ document_url: path })
      .eq("id", inserted.id)
      .select()
      .single();
    if (updateError) {
      console.error("Erreur enregistrement document_url:", updateError);
      setContracts((p) => [inserted, ...p]);
      return;
    }
    setContracts((p) => [updated, ...p]);
  }
  async function updateContract(id, { name, signed_date, hourly_rate, file, oldDocumentUrl }) {
    const { data: { user } } = await supabase.auth.getUser();
    let documentUrl = oldDocumentUrl || null;
    if (file) {
      if (oldDocumentUrl) await supabase.storage.from("contracts").remove([oldDocumentUrl]);
      const path = `${user.id}/${id}-${file.name}`;
      const { error: uploadError } = await supabase.storage.from("contracts").upload(path, file, { upsert: true });
      if (!uploadError) documentUrl = path;
    }
    const { data, error } = await supabase
      .from("contracts")
      .update({
        employer: name,
        signed_date: signed_date || null,
        hourly_rate: hourly_rate === "" || hourly_rate == null ? null : parseFloat(hourly_rate),
        document_url: documentUrl,
      })
      .eq("id", id)
      .select()
      .single();
    if (!error && data) setContracts((p) => p.map((c) => (c.id === id ? data : c)));
  }
  async function deleteContract(id, documentUrl) {
    if (documentUrl) await supabase.storage.from("contracts").remove([documentUrl]);
    await supabase.from("contracts").delete().eq("id", id);
    setContracts((p) => p.filter((c) => c.id !== id));
  }
  async function getContractFileUrl(path) {
    const { data } = await supabase.storage.from("contracts").createSignedUrl(path, 3600);
    return data?.signedUrl || null;
  }

  // --- Cours ---
  async function addCourse(name) {
    const { data: { user } } = await supabase.auth.getUser();
    const { data, error } = await supabase.from("courses").insert({ name, color: MARKER, user_id: user.id }).select().single();
    if (!error && data) setCourses((p) => [...p, data]);
  }
  async function deleteCourse(courseId) {
    // Nettoyage best-effort des fichiers liés (résumés, documents) avant suppression en cascade
    const relatedChapters = chapters.filter((c) => c.course_id === courseId);
    const chapterIds = relatedChapters.map((c) => c.id);
    const filesToRemove = [
      ...courseDocuments.filter((d) => d.course_id === courseId).map((d) => d.file_path),
      ...relatedChapters.filter((c) => c.summary_path).map((c) => c.summary_path),
      ...chapterDocuments.filter((d) => chapterIds.includes(d.chapter_id)).map((d) => d.file_path),
      ...homework.filter((h) => h.course_id === courseId && h.document_path).map((h) => h.document_path),
    ];
    if (filesToRemove.length) await supabase.storage.from("contracts").remove(filesToRemove);

    await supabase.from("courses").delete().eq("id", courseId);
    setCourses((p) => p.filter((c) => c.id !== courseId));
    setChapters((p) => p.filter((c) => c.course_id !== courseId));
    setCourseDocuments((p) => p.filter((d) => d.course_id !== courseId));
    setChapterDocuments((p) => p.filter((d) => !chapterIds.includes(d.chapter_id)));
    setHomework((p) => p.filter((h) => h.course_id !== courseId));
  }

  // --- Devoirs ---
  async function addHomework(h) {
    const { data: { user } } = await supabase.auth.getUser();
    const { data, error } = await supabase.from("homework").insert({ ...h, user_id: user.id }).select().single();
    if (!error && data) setHomework((p) => [...p, data]);
  }
  async function toggleHomework(id, done) {
    await supabase.from("homework").update({ done: !done }).eq("id", id);
    setHomework((p) => p.map((x) => (x.id === id ? { ...x, done: !x.done } : x)));
  }
  async function removeHomework(id) {
    await supabase.from("homework").delete().eq("id", id);
    setHomework((p) => p.filter((x) => x.id !== id));
  }

  // --- Événements ---
  async function addEvent(title, date) {
    const { data: { user } } = await supabase.auth.getUser();
    const { data, error } = await supabase.from("events").insert({ title, event_date: date || null, user_id: user.id }).select().single();
    if (!error && data) setEvents((p) => [...p, data]);
  }
  async function removeEvent(id) {
    await supabase.from("events").delete().eq("id", id);
    setEvents((p) => p.filter((x) => x.id !== id));
  }
  async function refreshEvents() {
    const { data } = await supabase.from("events").select("*");
    if (data) setEvents(data);
    const { data: settings } = await supabase.from("hour_counter_settings").select("*").maybeSingle();
    if (settings) setCounterSettings(settings);
  }

  // --- Liens importants ---
  async function addLink(name, url) {
    const { data: { user } } = await supabase.auth.getUser();
    let fullUrl = url.trim();
    if (!/^https?:\/\//i.test(fullUrl)) fullUrl = "https://" + fullUrl;
    const { data, error } = await supabase.from("important_links").insert({ name, url: fullUrl, user_id: user.id }).select().single();
    if (!error && data) setLinks((p) => [data, ...p]);
  }
  async function removeLink(id) {
    await supabase.from("important_links").delete().eq("id", id);
    setLinks((p) => p.filter((l) => l.id !== id));
  }

  // --- PDF résumé de l'année (un seul, remplacé à chaque envoi) ---
  async function uploadCalendarPdf(file) {
    const { data: { user } } = await supabase.auth.getUser();
    if (counterSettings.calendar_pdf_path) {
      await supabase.storage.from("contracts").remove([counterSettings.calendar_pdf_path]);
    }
    const path = `${user.id}/calendar-summary-${Date.now()}-${file.name}`;
    const { error: uploadError } = await supabase.storage.from("contracts").upload(path, file);
    if (uploadError) return;
    const { data, error } = await supabase
      .from("hour_counter_settings")
      .upsert({ ...counterSettings, user_id: user.id, calendar_pdf_path: path }, { onConflict: "user_id" })
      .select()
      .single();
    if (!error && data) setCounterSettings(data);
  }
  async function removeCalendarPdf() {
    if (!counterSettings.calendar_pdf_path) return;
    await supabase.storage.from("contracts").remove([counterSettings.calendar_pdf_path]);
    const { data, error } = await supabase
      .from("hour_counter_settings")
      .update({ calendar_pdf_path: null })
      .eq("user_id", counterSettings.user_id)
      .select()
      .single();
    if (!error && data) setCounterSettings(data);
    else setCounterSettings((p) => ({ ...p, calendar_pdf_path: null }));
  }
  async function viewCalendarPdf() {
    if (!counterSettings.calendar_pdf_path) return;
    const { data } = await supabase.storage.from("contracts").createSignedUrl(counterSettings.calendar_pdf_path, 3600);
    if (data?.signedUrl) window.open(data.signedUrl, "_blank");
  }

  // --- Chapitres (avec devoirs et résumé par chapitre) ---
  async function addChapter(courseId, name) {
    const { data: { user } } = await supabase.auth.getUser();
    const { data, error } = await supabase.from("chapters").insert({ user_id: user.id, course_id: courseId, name }).select().single();
    if (!error && data) setChapters((p) => [...p, data]);
  }
  async function deleteChapter(id) {
    await supabase.from("chapters").delete().eq("id", id);
    setChapters((p) => p.filter((c) => c.id !== id));
  }
  async function uploadChapterSummary(chapterId, file) {
    const { data: { user } } = await supabase.auth.getUser();
    const path = `${user.id}/chapter-${chapterId}-${Date.now()}-${file.name}`;
    const { error: uploadError } = await supabase.storage.from("contracts").upload(path, file);
    if (uploadError) { console.error("Erreur upload résumé chapitre:", uploadError); return; }
    const { data, error } = await supabase.from("chapters").update({ summary_path: path }).eq("id", chapterId).select().single();
    if (!error && data) setChapters((p) => p.map((c) => (c.id === chapterId ? data : c)));
    else console.error("Erreur enregistrement résumé chapitre:", error);
  }
  async function removeChapterSummary(chapterId, oldPath) {
    if (oldPath) await supabase.storage.from("contracts").remove([oldPath]);
    const { data, error } = await supabase.from("chapters").update({ summary_path: null }).eq("id", chapterId).select().single();
    if (!error && data) setChapters((p) => p.map((c) => (c.id === chapterId ? data : c)));
  }
  async function viewChapterSummary(path) {
    const { data } = await supabase.storage.from("contracts").createSignedUrl(path, 3600);
    if (data?.signedUrl) window.open(data.signedUrl, "_blank");
  }

  // --- Documents de chapitre (plusieurs, séparés du résumé) ---
  async function addChapterDocument(chapterId, name, file) {
    const { data: { user } } = await supabase.auth.getUser();
    const path = `${user.id}/chapterdoc-${chapterId}-${Date.now()}-${file.name}`;
    const { error: uploadError } = await supabase.storage.from("contracts").upload(path, file);
    if (uploadError) { console.error("Erreur upload document chapitre:", uploadError); return; }
    const { data, error } = await supabase
      .from("chapter_documents")
      .insert({ user_id: user.id, chapter_id: chapterId, name: name || file.name, file_path: path })
      .select()
      .single();
    if (!error && data) setChapterDocuments((p) => [...p, data]);
  }
  async function deleteChapterDocument(id, filePath) {
    await supabase.storage.from("contracts").remove([filePath]);
    await supabase.from("chapter_documents").delete().eq("id", id);
    setChapterDocuments((p) => p.filter((d) => d.id !== id));
  }
  async function viewChapterDocument(filePath) {
    const { data } = await supabase.storage.from("contracts").createSignedUrl(filePath, 3600);
    if (data?.signedUrl) window.open(data.signedUrl, "_blank");
  }

  // --- Documents par cours (plusieurs par cours) ---
  async function addCourseDocument(courseId, name, file) {
    const { data: { user } } = await supabase.auth.getUser();
    const path = `${user.id}/course-${courseId}-${Date.now()}-${file.name}`;
    const { error: uploadError } = await supabase.storage.from("contracts").upload(path, file);
    if (uploadError) { console.error("Erreur upload document cours:", uploadError); return; }
    const { data, error } = await supabase
      .from("course_documents")
      .insert({ user_id: user.id, course_id: courseId, name: name || file.name, file_path: path })
      .select()
      .single();
    if (!error && data) setCourseDocuments((p) => [...p, data]);
  }
  async function deleteCourseDocument(id, filePath) {
    await supabase.storage.from("contracts").remove([filePath]);
    await supabase.from("course_documents").delete().eq("id", id);
    setCourseDocuments((p) => p.filter((d) => d.id !== id));
  }
  async function viewCourseDocument(filePath) {
    const { data } = await supabase.storage.from("contracts").createSignedUrl(filePath, 3600);
    if (data?.signedUrl) window.open(data.signedUrl, "_blank");
  }

  async function uploadHomeworkDocument(homeworkId, file) {
    const { data: { user } } = await supabase.auth.getUser();
    const path = `${user.id}/homework-${homeworkId}-${Date.now()}-${file.name}`;
    const { error: uploadError } = await supabase.storage.from("contracts").upload(path, file);
    if (uploadError) { console.error("Erreur upload document devoir:", uploadError); return; }
    const { data, error } = await supabase.from("homework").update({ document_path: path }).eq("id", homeworkId).select().single();
    if (!error && data) setHomework((p) => p.map((h) => (h.id === homeworkId ? data : h)));
  }
  async function removeHomeworkDocument(homeworkId, oldPath) {
    if (oldPath) await supabase.storage.from("contracts").remove([oldPath]);
    const { data, error } = await supabase.from("homework").update({ document_path: null }).eq("id", homeworkId).select().single();
    if (!error && data) setHomework((p) => p.map((h) => (h.id === homeworkId ? data : h)));
  }
  async function viewHomeworkDocument(path) {
    const { data } = await supabase.storage.from("contracts").createSignedUrl(path, 3600);
    if (data?.signedUrl) window.open(data.signedUrl, "_blank");
  }

  // --- Tâches personnelles ---
  async function addTask(text, taskDate, taskTime) {
    const { data: { user } } = await supabase.auth.getUser();
    const { data, error } = await supabase
      .from("personal_tasks")
      .insert({ user_id: user.id, text, task_date: taskDate || null, task_time: taskTime || null, done: false })
      .select()
      .single();
    if (!error && data) setPersonalTasks((p) => [...p, data]);
  }
  async function toggleTask(id, done) {
    await supabase.from("personal_tasks").update({ done: !done }).eq("id", id);
    setPersonalTasks((p) => p.map((t) => (t.id === id ? { ...t, done: !t.done } : t)));
  }
  async function removeTask(id) {
    await supabase.from("personal_tasks").delete().eq("id", id);
    setPersonalTasks((p) => p.filter((t) => t.id !== id));
  }

  // --- Suggestions des testeurs ---
  async function addFeedback(text) {
    const { data: { user } } = await supabase.auth.getUser();
    const { data, error } = await supabase.from("feedback").insert({ user_id: user.id, text }).select().single();
    if (!error && data) setFeedback((p) => [data, ...p]);
  }

  // --- Heures ajoutées manuellement (pour une date précise, pas récurrent) ---
  async function addManualHours(date, hours, note) {
    const { data: { user } } = await supabase.auth.getUser();
    const minutes = Math.round(parseFloat(hours) * 60);
    if (!minutes) return;
    const { data, error } = await supabase
      .from("manual_hours")
      .insert({ user_id: user.id, entry_date: date, minutes, note: note || null })
      .select()
      .single();
    if (!error && data) setManualHours((p) => [data, ...p]);
  }
  async function removeManualHours(id) {
    await supabase.from("manual_hours").delete().eq("id", id);
    setManualHours((p) => p.filter((m) => m.id !== id));
  }

  // --- Documents personnels / administratifs ---
  async function addPersonalDocument(name, category, file, expirationDate) {
    const { data: { user } } = await supabase.auth.getUser();
    const path = `${user.id}/personaldoc-${Date.now()}-${file.name}`;
    const { error: uploadError } = await supabase.storage.from("contracts").upload(path, file);
    if (uploadError) { console.error("Erreur upload document personnel:", uploadError); return; }
    const { data, error } = await supabase
      .from("personal_documents")
      .insert({ user_id: user.id, name: name || file.name, category, file_path: path, expiration_date: expirationDate || null })
      .select()
      .single();
    if (!error && data) setPersonalDocuments((p) => [data, ...p]);
  }
  async function removePersonalDocument(id, filePath) {
    await supabase.storage.from("contracts").remove([filePath]);
    await supabase.from("personal_documents").delete().eq("id", id);
    setPersonalDocuments((p) => p.filter((d) => d.id !== id));
  }
  async function viewPersonalDocument(filePath) {
    const { data } = await supabase.storage.from("contracts").createSignedUrl(filePath, 3600);
    if (data?.signedUrl) window.open(data.signedUrl, "_blank");
  }

  const nav = [
    { id: "planning", label: "🏠 Accueil & Travail", icon: <Briefcase size={16} /> },
    { id: "contrat", label: "📄 Contrats", icon: <Clock size={16} /> },
    { id: "cours", label: "📚 Études", icon: <BookOpen size={16} /> },
    { id: "calendrier", label: "📅 Calendrier universitaire", icon: <CalendarDays size={16} /> },
    { id: "liens", label: "🔗 Liens utiles", icon: <Link2 size={16} /> },
    { id: "taches", label: "✅ Tâches personnelles", icon: <Clock size={16} style={{ opacity: 0.7 }} /> },
    { id: "suggestions", label: "💡 Suggestions", icon: <ExternalLink size={16} /> },
    { id: "faq", label: "❓ FAQ étudiants", icon: <BookOpen size={16} style={{ opacity: 0.7 }} /> },
    { id: "documents", label: "🗂️ Documents importants", icon: <Upload size={16} style={{ opacity: 0.7 }} /> },
    { id: "aide", label: "🧭 Aide / Comment ça marche", icon: <ExternalLink size={16} style={{ opacity: 0.7 }} /> },
  ];

  const navGroups = [
    { label: "MON TRAVAIL", ids: ["planning", "contrat"] },
    { label: "MES ÉTUDES", ids: ["cours", "calendrier"] },
    { label: "MON ORGANISATION", ids: ["taches", "documents", "liens"] },
    { label: "AIDE", ids: ["faq", "aide", "suggestions"] },
  ];

  if (loading) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: PAPER }}>
        <p style={{ color: INK }}>Chargement...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen font-sans" style={{ background: PAPER }}>
      <div className="max-w-5xl mx-auto p-4 md:p-8">
        <header className="mb-4 flex items-start justify-between gap-3">
          <div>
            <p className="text-xs uppercase tracking-[0.2em]" style={{ color: TEAL }}>Carnet Étudiant</p>
            <h1 className="text-3xl md:text-4xl font-bold" style={{ color: INK }}>Bonjour 👋</h1>
          </div>
          <div className="flex gap-2">
            <button onClick={handleLogout} className="flex-shrink-0 rounded-xl p-2.5" style={{ background: "#fff", border: "1px solid #ddd", color: INK }}>
              <LogOut size={18} />
            </button>
            <button onClick={() => setMenuOpen(true)} className="flex-shrink-0 rounded-xl p-2.5" style={{ background: INK, color: PAPER }}>
              <Menu size={20} />
            </button>
          </div>
        </header>

        {tab === "planning" && <InstallBanner />}
        {tab === "planning" && <Dashboard shifts={shifts} manualHours={manualHours} homework={homework} events={events} tasks={personalTasks} startDate={counterSettings.start_date} annualQuotaHours={ANNUAL_QUOTA_HOURS} />}

        <div className="flex items-center gap-2 mb-6 text-sm" style={{ color: INK }}>
          {nav.find((n) => n.id === tab)?.icon}
          <span className="font-medium">{nav.find((n) => n.id === tab)?.label}</span>
        </div>

        {menuOpen && (
          <div className="fixed inset-0 z-50 flex">
            <div className="absolute inset-0 bg-black/40" onClick={() => setMenuOpen(false)} />
            <div className="relative w-72 max-w-[85%] h-full p-5 flex flex-col gap-1 overflow-y-auto" style={{ background: INK, color: PAPER }}>
              <div className="flex items-center justify-between mb-6">
                <span className="text-lg font-bold">Menu</span>
                <button onClick={() => setMenuOpen(false)}><X size={20} /></button>
              </div>
              {navGroups.map((group) => {
                const isOpen = openGroup === group.label;
                const containsActive = group.ids.includes(tab);
                return (
                  <div key={group.label} className="mb-1">
                    <button
                      onClick={() => setOpenGroup(isOpen ? null : group.label)}
                      className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-semibold"
                      style={{ background: containsActive && !isOpen ? "rgba(255,255,255,0.06)" : "transparent", color: PAPER }}
                    >
                      <span className="text-xs uppercase tracking-[0.1em] opacity-70">{group.label}</span>
                      <span style={{ transform: isOpen ? "rotate(45deg)" : "none", transition: "transform 0.15s" }}>+</span>
                    </button>
                    {isOpen && (
                      <div className="pl-1 mb-2">
                        {group.ids.map((id) => {
                          const n = nav.find((x) => x.id === id);
                          if (!n) return null;
                          return (
                            <button
                              key={n.id}
                              onClick={() => { setTab(n.id); setMenuOpen(false); }}
                              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-left"
                              style={{ background: tab === n.id ? "rgba(255,255,255,0.1)" : "transparent", color: tab === n.id ? MARKER : PAPER }}
                            >
                              {n.icon} {n.label}
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {tab === "planning" && (
          <PlanningTab
            shifts={shifts}
            events={events}
            manualHours={manualHours}
            onAddManualHours={addManualHours}
            onRemoveManualHours={removeManualHours}
            startDate={counterSettings.start_date}
            onStartDateChange={updateStartDate}
            annualQuotaHours={ANNUAL_QUOTA_HOURS}
            onAddShift={addShift}
            onRemoveShift={removeShift}
          />
        )}
        {tab === "contrat" && (
          <ContractsTab contracts={contracts} onAdd={addContract} onUpdate={updateContract} onDelete={deleteContract} getFileUrl={getContractFileUrl} />
        )}
        {tab === "cours" && (
          <CoursesTab
            courses={courses}
            chapters={chapters}
            homework={homework}
            documents={courseDocuments}
            chapterDocuments={chapterDocuments}
            onAddCourse={addCourse}
            onDeleteCourse={deleteCourse}
            onAddChapter={addChapter}
            onRemoveChapter={deleteChapter}
            onUploadSummary={uploadChapterSummary}
            onRemoveSummary={removeChapterSummary}
            onViewSummary={viewChapterSummary}
            onAddChapterDoc={addChapterDocument}
            onRemoveChapterDoc={deleteChapterDocument}
            onViewChapterDoc={viewChapterDocument}
            onAddHomework={addHomework}
            onToggleHomework={toggleHomework}
            onRemoveHomework={removeHomework}
            onAddDocument={addCourseDocument}
            onRemoveDocument={deleteCourseDocument}
            onViewDocument={viewCourseDocument}
            onUploadHomeworkDoc={uploadHomeworkDocument}
            onRemoveHomeworkDoc={removeHomeworkDocument}
            onViewHomeworkDoc={viewHomeworkDocument}
          />
        )}
        {tab === "taches" && <TasksTab tasks={personalTasks} onAdd={addTask} onToggle={toggleTask} onRemove={removeTask} />}
        {tab === "suggestions" && <FeedbackTab feedback={feedback} onAdd={addFeedback} />}
        {tab === "faq" && <FaqTab />}
        {tab === "aide" && <HelpTab />}
        {tab === "documents" && (
          <PersonalDocumentsTab documents={personalDocuments} onAdd={addPersonalDocument} onRemove={removePersonalDocument} onView={viewPersonalDocument} />
        )}
        <OnboardingModal />
        {tab === "calendrier" && (
          <CalendarTab
            events={events}
            onAddEvent={addEvent}
            onRemoveEvent={removeEvent}
            calendarUrl={counterSettings.university_calendar_url}
            onSyncUrl={refreshEvents}
            calendarPdfPath={counterSettings.calendar_pdf_path}
            onUploadPdf={uploadCalendarPdf}
            onRemovePdf={removeCalendarPdf}
            onViewPdf={viewCalendarPdf}
          />
        )}
        {tab === "liens" && <LinksTab links={links} onAdd={addLink} onRemove={removeLink} />}
      </div>
    </div>
  );
}

function InstallBanner() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const dismissed = window.localStorage.getItem("carnet_install_banner_dismissed");
    const onboarded = window.localStorage.getItem("carnet_onboarding_seen");
    // On l'affiche seulement une fois que l'onboarding a été vu, pour ne pas empiler deux popups
    if (!dismissed && onboarded) setShow(true);
  }, []);

  function dismiss() {
    window.localStorage.setItem("carnet_install_banner_dismissed", "1");
    setShow(false);
  }

  if (!show) return null;

  return (
    <div className="rounded-xl px-4 py-3 mb-4 flex items-center gap-3 text-sm" style={{ background: `${TEAL}15`, border: `1px solid ${TEAL}40`, color: INK }}>
      <span>📲</span>
      <span className="flex-1">
        Ajoute Carnet Étudiant à ton écran d'accueil pour l'ouvrir comme une vraie app — Android : menu ⋮ → "Installer". iPhone : Partager → "Sur l'écran d'accueil".
      </span>
      <button onClick={dismiss} style={{ color: TEAL, flexShrink: 0 }}><X size={16} /></button>
    </div>
  );
}

function Dashboard({ shifts, manualHours, homework, events, tasks, startDate, annualQuotaHours }) {
  const now = new Date();
  const workedMin = useMemo(() => computeWorkedMinutes(shifts, new Date(startDate), now, manualHours), [shifts, startDate, manualHours]);
  const remainingMin = Math.max(0, annualQuotaHours * 60 - workedMin);

  const upcomingHomework = homework
    .filter((h) => !h.done && h.due_date)
    .sort((a, b) => a.due_date.localeCompare(b.due_date))
    .slice(0, 3);
  const upcomingTasks = tasks
    .filter((t) => !t.done)
    .sort((a, b) => (a.task_date || "9999").localeCompare(b.task_date || "9999"))
    .slice(0, 3);
  const upcomingEvents = events
    .filter((e) => e.event_date && e.event_date >= now.toISOString().slice(0, 10))
    .sort((a, b) => a.event_date.localeCompare(b.event_date))
    .slice(0, 3);

  return (
    <div className="grid sm:grid-cols-3 gap-3 mb-6">
      <div className="rounded-xl p-4" style={{ background: INK, color: PAPER }}>
        <p className="text-xs opacity-60 mb-1">Quota annuel</p>
        <p className="text-xl font-bold font-mono" style={{ color: MARKER }}>{fmtHours(remainingMin)} restant</p>
      </div>
      <div className="rounded-xl p-4 bg-white" style={{ border: "1px solid #e5e5e0" }}>
        <p className="text-xs text-neutral-500 mb-1.5">Prochains devoirs</p>
        {upcomingHomework.length === 0 && <p className="text-xs text-neutral-400">Rien à signaler 👍</p>}
        {upcomingHomework.map((h) => (
          <p key={h.id} className="text-xs" style={{ color: INK }}>{h.title} — <span className="text-neutral-400">{fmtRelativeDate(h.due_date, now)}</span></p>
        ))}
      </div>
      <div className="rounded-xl p-4 bg-white" style={{ border: "1px solid #e5e5e0" }}>
        <p className="text-xs text-neutral-500 mb-1.5">À venir</p>
        {[...upcomingTasks.map((t) => ({ id: "t" + t.id, label: t.text, date: t.task_date })), ...upcomingEvents.map((e) => ({ id: "e" + e.id, label: e.title, date: e.event_date }))]
          .slice(0, 3)
          .map((item) => (
            <p key={item.id} className="text-xs" style={{ color: INK }}>{item.label} {item.date ? <span className="text-neutral-400">— {fmtRelativeDate(item.date, now)}</span> : null}</p>
          ))}
        {upcomingTasks.length === 0 && upcomingEvents.length === 0 && <p className="text-xs text-neutral-400">Rien à signaler 👍</p>}
      </div>
    </div>
  );
}

function ManualHoursSection({ manualHours, onAdd, onRemove }) {
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [hours, setHours] = useState("");
  const [note, setNote] = useState("");

  return (
    <div className="bg-white rounded-2xl p-5 md:p-6" style={{ border: "1px solid #e5e5e0" }}>
      <h2 className="text-lg font-semibold mb-1" style={{ color: INK }}>Ajouter des heures pour un jour précis</h2>
      <p className="text-xs text-neutral-500 mb-3">
        Utile si tu as travaillé un jour exceptionnel (pas toutes les semaines) — ça s'ajoute directement au total, sans se répéter.
      </p>
      <div className="flex flex-wrap gap-2 items-end mb-3">
        <div>
          <label className="text-xs text-neutral-500 block mb-1">Date</label>
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="border rounded-lg px-2 py-1.5 text-sm" />
        </div>
        <div>
          <label className="text-xs text-neutral-500 block mb-1">Heures travaillées</label>
          <input value={hours} onChange={(e) => setHours(e.target.value)} placeholder="Ex: 3.5" className="border rounded-lg px-2 py-1.5 text-sm w-24" />
        </div>
        <div className="flex-1 min-w-[120px]">
          <label className="text-xs text-neutral-500 block mb-1">Note (optionnel)</label>
          <input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Ex: remplacement" className="border rounded-lg px-2 py-1.5 text-sm w-full" />
        </div>
        <button
          onClick={() => { if (hours) { onAdd(date, hours, note); setHours(""); setNote(""); } }}
          className="rounded-lg px-3 py-1.5 text-sm font-medium text-white flex items-center gap-1"
          style={{ background: INK }}
        >
          <Plus size={14} /> Ajouter
        </button>
      </div>
      {manualHours.length > 0 && (
        <div className="space-y-1.5">
          {manualHours.slice(0, 5).map((m) => (
            <div key={m.id} className="flex items-center gap-2 text-xs rounded-lg px-2 py-1.5" style={{ background: "#fafaf7" }}>
              <span className="font-mono">{new Date(m.entry_date + "T00:00:00").toLocaleDateString("fr-FR")}</span>
              <span className="font-semibold" style={{ color: TEAL }}>{fmtHours(m.minutes)}</span>
              {m.note && <span className="text-neutral-400">— {m.note}</span>}
              <button onClick={() => onRemove(m.id)} className="ml-auto"><Trash2 size={12} className="text-neutral-400" /></button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function QuotaProgress({ workedMin, annualQuotaHours, shifts, now }) {
  const quotaMin = annualQuotaHours * 60;
  const remainingMin = Math.max(0, quotaMin - workedMin);
  const pct = Math.min(100, (workedMin / quotaMin) * 100);

  let level = { color: TEAL, emoji: "🟢", label: "Aucun risque actuellement." };
  if (pct >= 95) level = { color: "#FF6B57", emoji: "🔴", label: "Attention, il reste très peu d'heures !" };
  else if (pct >= 80) level = { color: MARKER, emoji: "🟠", label: "Attention, ça se rapproche du quota." };

  const projected = remainingMin > 0 ? projectQuotaDate(remainingMin, shifts, now) : null;

  return (
    <div className="mb-2">
      <div className="flex items-baseline justify-between mb-1.5">
        <span className="text-lg font-mono" style={{ color: level.color }}>
          {level.emoji} {fmtHours(remainingMin)} restant{remainingMin > 1 ? "es" : ""}
        </span>
        <span className="text-xs font-mono opacity-60">{pct.toFixed(1)}% utilisés</span>
      </div>
      <div className="w-full h-2.5 rounded-full overflow-hidden mb-2" style={{ background: "rgba(255,255,255,0.15)" }}>
        <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: level.color }} />
      </div>
      <p className="text-xs opacity-70 mb-1">{level.label}</p>
      {projected && (
        <p className="text-xs opacity-60">
          À ce rythme, tu atteindras {annualQuotaHours}h vers le {projected.toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}.
        </p>
      )}
    </div>
  );
}

function exportHoursPDF(shifts, manualHours, startDate) {
  const DAYS_FULL = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
  let totalMin = 0;
  const rows = [];

  shifts.forEach((s) => {
    const durMin = toMinutes(s.end_time) - toMinutes(s.start_time);
    totalMin += 0; // les créneaux récurrents ne sont pas sommés directement ici, seulement listés
    rows.push(`<tr><td>Créneau récurrent</td><td>${DAYS_FULL[s.day_of_week]}</td><td>${s.start_time} – ${s.end_time}</td><td>${(durMin / 60).toFixed(2)}h</td><td>${s.label || ""}</td></tr>`);
  });
  manualHours.forEach((m) => {
    totalMin += m.minutes;
    rows.push(`<tr><td>Heures ponctuelles</td><td>${new Date(m.entry_date + "T00:00:00").toLocaleDateString("fr-FR")}</td><td>—</td><td>${(m.minutes / 60).toFixed(2)}h</td><td>${m.note || ""}</td></tr>`);
  });

  const html = `
    <html>
    <head>
      <meta charset="utf-8" />
      <title>Relevé d'heures</title>
      <style>
        body { font-family: Arial, sans-serif; padding: 40px; color: #14162B; }
        h1 { font-size: 20px; margin-bottom: 4px; }
        p.sub { color: #666; font-size: 12px; margin-top: 0; margin-bottom: 24px; }
        table { width: 100%; border-collapse: collapse; font-size: 12px; }
        th, td { border: 1px solid #ddd; padding: 6px 8px; text-align: left; }
        th { background: #f5f5f0; }
        .total { margin-top: 16px; font-weight: bold; font-size: 14px; }
      </style>
    </head>
    <body>
      <h1>Relevé d'heures travaillées — Carnet Étudiant</h1>
      <p class="sub">Depuis le ${new Date(startDate).toLocaleDateString("fr-FR")} — généré le ${new Date().toLocaleDateString("fr-FR")}</p>
      <table>
        <thead><tr><th>Type</th><th>Jour / Date</th><th>Horaire</th><th>Durée</th><th>Note</th></tr></thead>
        <tbody>${rows.join("")}</tbody>
      </table>
      <p class="total">Total heures ponctuelles ajoutées : ${(totalMin / 60).toFixed(2)}h (hors créneaux récurrents, voir liste ci-dessus)</p>
      <script>window.onload = () => window.print();</script>
    </body>
    </html>
  `;
  const win = window.open("", "_blank");
  win.document.write(html);
  win.document.close();
}

function exportHoursCSV(shifts, manualHours, startDate) {
  const rows = [["Type", "Jour/Date", "Début", "Fin", "Durée (h)", "Note"]];
  const DAYS_FULL = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];

  shifts.forEach((s) => {
    const durH = ((toMinutes(s.end_time) - toMinutes(s.start_time)) / 60).toFixed(2);
    rows.push(["Créneau récurrent", DAYS_FULL[s.day_of_week], s.start_time, s.end_time, durH, s.label || ""]);
  });
  manualHours.forEach((m) => {
    const durH = (m.minutes / 60).toFixed(2);
    rows.push(["Heures ponctuelles", m.entry_date, "", "", durH, m.note || ""]);
  });

  const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(";")).join("\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `releve-heures-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

function WeeklyHoursChart({ shifts, manualHours, now }) {
  const weeks = useMemo(() => {
    const result = [];
    for (let i = 7; i >= 0; i--) {
      const weekEnd = new Date(now);
      weekEnd.setDate(weekEnd.getDate() - i * 7);
      const weekStart = new Date(weekEnd);
      weekStart.setDate(weekStart.getDate() - 6);
      weekStart.setHours(0, 0, 0, 0);
      weekEnd.setHours(23, 59, 59, 999);

      let mins = 0;
      const cursor = new Date(weekStart);
      while (cursor <= weekEnd && cursor <= now) {
        const dow = cursor.getDay();
        shifts.forEach((s) => {
          if (s.day_of_week === dow) mins += toMinutes(s.end_time) - toMinutes(s.start_time);
        });
        cursor.setDate(cursor.getDate() + 1);
      }
      manualHours.forEach((m) => {
        const d = new Date(m.entry_date + "T00:00:00");
        if (d >= weekStart && d <= weekEnd) mins += m.minutes;
      });

      result.push({ label: weekStart.toLocaleDateString("fr-FR", { day: "numeric", month: "short" }), mins });
    }
    return result;
  }, [shifts, manualHours, now]);

  const maxMin = Math.max(...weeks.map((w) => w.mins), 60);

  return (
    <div className="bg-white rounded-2xl p-5 md:p-6" style={{ border: "1px solid #e5e5e0" }}>
      <h2 className="text-lg font-semibold mb-4" style={{ color: INK }}>Heures par semaine (8 dernières)</h2>
      <div className="flex items-end gap-2" style={{ height: 120 }}>
        {weeks.map((w, i) => (
          <div key={i} className="flex-1 flex flex-col items-center justify-end h-full">
            <span className="text-[10px] text-neutral-400 mb-1">{w.mins > 0 ? fmtHours(w.mins) : ""}</span>
            <div
              className="w-full rounded-t-md"
              style={{ height: `${Math.max(4, (w.mins / maxMin) * 90)}px`, background: i === 7 ? MARKER : `${INK}55` }}
            />
            <span className="text-[10px] text-neutral-400 mt-1">{w.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function QuickAdjustHours({ onAdd }) {
  const [amount, setAmount] = useState("");
  const [sign, setSign] = useState(1);
  const [busy, setBusy] = useState(false);

  async function handleAdd() {
    if (!amount) return;
    setBusy(true);
    const today = new Date().toISOString().slice(0, 10);
    await onAdd(today, sign * parseFloat(amount), "Ajustement rapide");
    setAmount("");
    setBusy(false);
  }

  return (
    <div className="flex items-center gap-2 mt-3">
      <button
        onClick={() => setSign(sign === 1 ? -1 : 1)}
        className="rounded-lg px-3 py-1.5 text-sm font-bold"
        style={{ background: sign === 1 ? `${TEAL}33` : "#FF6B5733", color: sign === 1 ? TEAL : "#FF6B57" }}
      >
        {sign === 1 ? "+" : "−"}
      </button>
      <input
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
        placeholder="Ex: 12"
        className="text-sm bg-transparent border rounded px-2 py-1.5 w-20"
        style={{ borderColor: "rgba(255,255,255,0.3)", color: PAPER }}
      />
      <span className="text-xs opacity-60">heures, ajouté à aujourd'hui</span>
      <button onClick={handleAdd} disabled={busy || !amount} className="ml-auto text-xs px-3 py-1.5 rounded-lg font-medium" style={{ background: MARKER, color: INK, opacity: busy || !amount ? 0.5 : 1 }}>
        Appliquer
      </button>
    </div>
  );
}

function PlanningTab({ shifts, events, manualHours, onAddManualHours, onRemoveManualHours, startDate, onStartDateChange, annualQuotaHours, onAddShift, onRemoveShift }) {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(t);
  }, []);
  const workedMin = useMemo(() => computeWorkedMinutes(shifts, new Date(startDate), now, manualHours), [shifts, startDate, now, manualHours]);
  const remainingMin = Math.max(0, annualQuotaHours * 60 - workedMin);

  // Cours de la semaine en cours (lundi -> dimanche), à partir des événements synchronisés avec horaires
  const weekCourses = useMemo(() => {
    const monday = new Date(now);
    const dow = monday.getDay();
    const diffToMonday = dow === 0 ? -6 : 1 - dow;
    monday.setDate(monday.getDate() + diffToMonday);
    monday.setHours(0, 0, 0, 0);
    const sunday = new Date(monday);
    sunday.setDate(sunday.getDate() + 6);
    sunday.setHours(23, 59, 59, 999);

    return events
      .filter((e) => e.start_time && e.event_date)
      .filter((e) => {
        const d = new Date(e.event_date + "T00:00:00");
        return d >= monday && d <= sunday;
      })
      .map((e) => ({ ...e, day: new Date(e.event_date + "T00:00:00").getDay() }));
  }, [events, now]);

  const [day, setDay] = useState(1);
  const [start, setStart] = useState("09:00");
  const [end, setEnd] = useState("17:00");
  const [label, setLabel] = useState("");

  return (
    <div className="space-y-5">
      <div className="relative rounded-2xl p-6 md:p-8" style={{ background: INK, border: "2px dashed rgba(255,255,255,0.25)", color: PAPER }}>
        <div className="flex justify-between items-start mb-6">
          <div>
            <p className="text-xs uppercase tracking-[0.2em] opacity-60">Carte de pointage</p>
            <p className="text-xl mt-1 font-semibold">Heures travaillées</p>
          </div>
          <Clock size={22} style={{ color: MARKER }} />
        </div>
        <div className="text-5xl md:text-6xl font-bold mb-2 font-mono" style={{ color: MARKER }}>{fmtHours(workedMin)}</div>
        <p className="text-sm opacity-60 mb-4">depuis le {new Date(startDate).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}</p>

        <QuotaProgress workedMin={workedMin} annualQuotaHours={annualQuotaHours} shifts={shifts} now={now} />

        <QuickAdjustHours onAdd={onAddManualHours} />

        <div className="flex items-center gap-3 pt-4 mt-5 flex-wrap" style={{ borderTop: "1px dashed rgba(255,255,255,0.2)" }}>
          <label className="text-xs opacity-60">Point de départ du compteur</label>
          <input type="date" value={startDate} onChange={(e) => onStartDateChange(e.target.value)} className="text-sm bg-transparent border rounded px-2 py-1" style={{ borderColor: "rgba(255,255,255,0.3)", color: PAPER, colorScheme: "dark" }} />
          <button
            onClick={() => { if (confirm("Réinitialiser le compteur à partir d'aujourd'hui ? Les heures déjà comptées avant aujourd'hui ne seront plus incluses dans le total.")) onStartDateChange(new Date().toISOString().slice(0, 10)); }}
            className="text-xs px-2.5 py-1.5 rounded-lg font-medium"
            style={{ background: "rgba(255,107,87,0.15)", color: "#FF6B57" }}
          >
            ↺ Réinitialiser le compteur
          </button>
          <button
            onClick={() => exportHoursCSV(shifts, manualHours, startDate)}
            className="ml-auto text-xs px-2.5 py-1.5 rounded-lg font-medium"
            style={{ background: "rgba(255,255,255,0.1)", color: PAPER }}
          >
            📥 CSV
          </button>
          <button
            onClick={() => exportHoursPDF(shifts, manualHours, startDate)}
            className="text-xs px-2.5 py-1.5 rounded-lg font-medium"
            style={{ background: "rgba(255,255,255,0.1)", color: PAPER }}
          >
            📄 PDF
          </button>
        </div>
      </div>

      <WeeklyHoursChart shifts={shifts} manualHours={manualHours} now={now} />

      <ManualHoursSection manualHours={manualHours} onAdd={onAddManualHours} onRemove={onRemoveManualHours} />

      <div className="bg-white rounded-2xl p-5 md:p-6" style={{ border: "1px solid #e5e5e0" }}>
        <h2 className="text-lg font-semibold mb-4" style={{ color: INK }}>Créneaux de travail</h2>
        <div className="flex flex-wrap gap-2 items-end mb-4">
          <div>
            <label className="text-xs text-neutral-500 block mb-1">Jour</label>
            <select value={day} onChange={(e) => setDay(Number(e.target.value))} className="border rounded-lg px-2 py-1.5 text-sm">
              {DAYS_FULL.map((d, i) => <option key={i} value={i}>{d}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs text-neutral-500 block mb-1">Début</label>
            <input type="time" value={start} onChange={(e) => setStart(e.target.value)} className="border rounded-lg px-2 py-1.5 text-sm" />
          </div>
          <div>
            <label className="text-xs text-neutral-500 block mb-1">Fin</label>
            <input type="time" value={end} onChange={(e) => setEnd(e.target.value)} className="border rounded-lg px-2 py-1.5 text-sm" />
          </div>
          <div className="flex-1 min-w-[120px]">
            <label className="text-xs text-neutral-500 block mb-1">Poste</label>
            <input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="Ex: Caisse" className="border rounded-lg px-2 py-1.5 text-sm w-full" />
          </div>
          <button
            onClick={() => { onAddShift({ day_of_week: day, start_time: start, end_time: end, label }); setLabel(""); }}
            className="rounded-lg px-3 py-1.5 text-sm font-medium text-white flex items-center gap-1"
            style={{ background: INK }}
          >
            <Plus size={14} /> Ajouter
          </button>
        </div>
        <div className="grid grid-cols-7 gap-2">
          {DAYS.map((d, i) => <div key={i} className="text-xs font-semibold text-center text-neutral-500 pb-1">{d}</div>)}
          {DAYS.map((_, i) => (
            <div key={i} className="min-h-[70px] rounded-lg p-1.5 flex flex-col gap-1" style={{ background: "#fff", border: "1px solid #e5e5e0" }}>
              {shifts.filter((s) => s.day_of_week === i).map((s) => (
                <div key={s.id} className="rounded px-1.5 py-1 text-[11px] font-mono relative group" style={{ background: `${MARKER}33`, color: "#7A5A00" }}>
                  <div className="font-semibold">{s.start_time}–{s.end_time}</div>
                  {s.label && <div className="opacity-70 truncate">{s.label}</div>}
                  <button onClick={() => onRemoveShift(s.id)} className="absolute top-0.5 right-0.5 opacity-0 group-hover:opacity-100">
                    <Trash2 size={10} />
                  </button>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ContractsTab({ contracts, onAdd, onUpdate, onDelete, getFileUrl }) {
  const [name, setName] = useState("");
  const [signedDate, setSignedDate] = useState("");
  const [rate, setRate] = useState("");
  const [file, setFile] = useState(null);
  const [saving, setSaving] = useState(false);
  const [fileUrls, setFileUrls] = useState({});
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({});
  const [editFile, setEditFile] = useState(null);

  async function handleAdd() {
    if (!name.trim()) return;
    setSaving(true);
    await onAdd({ name: name.trim(), signed_date: signedDate || null, hourly_rate: rate, file });
    setName(""); setSignedDate(""); setRate(""); setFile(null);
    setSaving(false);
  }

  async function handleView(c) {
    if (!c.document_url) return;
    if (fileUrls[c.id]) {
      window.open(fileUrls[c.id], "_blank");
      return;
    }
    const url = await getFileUrl(c.document_url);
    if (url) {
      setFileUrls((p) => ({ ...p, [c.id]: url }));
      window.open(url, "_blank");
    }
  }

  function startEdit(c) {
    setEditingId(c.id);
    setEditForm({ name: c.employer || "", signed_date: c.signed_date || "", hourly_rate: c.hourly_rate ?? "" });
    setEditFile(null);
  }

  async function handleSaveEdit(c) {
    await onUpdate(c.id, { ...editForm, file: editFile, oldDocumentUrl: c.document_url });
    setEditingId(null);
    setEditFile(null);
    setFileUrls((p) => { const n = { ...p }; delete n[c.id]; return n; });
  }

  return (
    <div className="space-y-5">
      <div className="bg-white rounded-2xl p-5 md:p-6" style={{ border: "1px solid #e5e5e0" }}>
        <h2 className="text-lg font-semibold mb-4" style={{ color: INK }}>Mes contrats</h2>
        <div className="space-y-2">
          {contracts.length === 0 && <p className="text-sm text-neutral-400">Aucun contrat enregistré pour l'instant.</p>}
          {contracts.map((c) =>
            editingId === c.id ? (
              <div key={c.id} className="rounded-xl p-3 space-y-2" style={{ border: `1px solid ${TEAL}` }}>
                <input value={editForm.name} onChange={(e) => setEditForm({ ...editForm, name: e.target.value })} className="border rounded-lg px-2 py-1.5 text-sm w-full" placeholder="Nom du contrat" />
                <div className="flex gap-2">
                  <input type="date" value={editForm.signed_date || ""} onChange={(e) => setEditForm({ ...editForm, signed_date: e.target.value })} className="border rounded-lg px-2 py-1.5 text-sm flex-1" />
                  <input value={editForm.hourly_rate} onChange={(e) => setEditForm({ ...editForm, hourly_rate: e.target.value })} className="border rounded-lg px-2 py-1.5 text-sm flex-1" placeholder="Taux horaire" />
                </div>
                {c.document_url && (
                  <button type="button" onClick={() => handleView(c)} className="text-xs px-2.5 py-1.5 rounded-lg font-medium w-fit" style={{ background: `${TEAL}22`, color: TEAL }}>
                    Voir / télécharger le fichier actuel
                  </button>
                )}
                <label className="flex items-center gap-2 border rounded-lg px-3 py-2 text-sm cursor-pointer" style={{ borderColor: "#ccc", background: editFile ? `${TEAL}11` : "#fafafa", color: editFile ? TEAL : "#666" }}>
                  <Upload size={14} />
                  {editFile ? editFile.name : c.document_url ? "Remplacer le fichier" : "Ajouter un fichier"}
                  <input type="file" accept="application/pdf,image/*" onChange={(e) => setEditFile(e.target.files?.[0] || null)} style={{ position: "absolute", width: 1, height: 1, opacity: 0, pointerEvents: "none" }} />
                </label>
                <div className="flex gap-2">
                  <button onClick={() => handleSaveEdit(c)} className="rounded-lg px-3 py-1.5 text-sm font-medium text-white" style={{ background: INK }}>Enregistrer</button>
                  <button onClick={() => setEditingId(null)} className="rounded-lg px-3 py-1.5 text-sm font-medium" style={{ background: "#f0f0ea", color: INK }}>Annuler</button>
                </div>
              </div>
            ) : (
              <div key={c.id} className="rounded-xl p-3 flex items-center gap-3" style={{ border: "1px solid #e5e5e0" }}>
                <div className="flex-1 cursor-pointer" onClick={() => startEdit(c)}>
                  <p className="text-sm font-semibold" style={{ color: INK }}>{c.employer}</p>
                  <p className="text-xs text-neutral-500">
                    {c.signed_date ? `Signé le ${new Date(c.signed_date).toLocaleDateString("fr-FR")}` : "Date non renseignée"}
                    {c.hourly_rate ? ` · ${c.hourly_rate} €/h` : ""}
                  </p>
                </div>
                {c.document_url && (
                  <button onClick={() => handleView(c)} className="text-xs px-2.5 py-1.5 rounded-lg font-medium" style={{ background: `${TEAL}22`, color: TEAL }}>
                    Voir le PDF
                  </button>
                )}
                <button onClick={() => startEdit(c)} className="text-xs px-2.5 py-1.5 rounded-lg font-medium" style={{ background: `${MARKER}33`, color: "#7A5A00" }}>
                  Modifier
                </button>
                <button onClick={() => onDelete(c.id, c.document_url)}><Trash2 size={14} className="text-neutral-400" /></button>
              </div>
            )
          )}
        </div>
      </div>

      <div className="bg-white rounded-2xl p-5 md:p-6" style={{ border: "1px solid #e5e5e0" }}>
        <h2 className="text-lg font-semibold mb-4" style={{ color: INK }}>Ajouter un contrat</h2>
        <div className="grid md:grid-cols-2 gap-4 text-sm mb-4">
          <div>
            <label className="text-xs text-neutral-500 block mb-1">Nom du contrat / employeur</label>
            <input value={name} onChange={(e) => setName(e.target.value)} className="border rounded-lg px-2 py-1.5 w-full" placeholder="Ex: Restaurant Le Central" />
          </div>
          <div>
            <label className="text-xs text-neutral-500 block mb-1">Date de signature</label>
            <input type="date" value={signedDate} onChange={(e) => setSignedDate(e.target.value)} className="border rounded-lg px-2 py-1.5 w-full" />
          </div>
          <div>
            <label className="text-xs text-neutral-500 block mb-1">Taux horaire (optionnel)</label>
            <input value={rate} onChange={(e) => setRate(e.target.value)} className="border rounded-lg px-2 py-1.5 w-full" placeholder="11.88" />
          </div>
          <div>
            <label className="text-xs text-neutral-500 block mb-1">Contrat signé (PDF ou photo)</label>
            <label
              htmlFor="contract-file-input"
              className="flex items-center gap-2 border rounded-lg px-3 py-2 text-sm cursor-pointer"
              style={{ borderColor: "#ccc", background: file ? `${TEAL}11` : "#fafafa", color: file ? TEAL : "#666" }}
            >
              <Upload size={14} />
              {file ? file.name : "Cliquer pour choisir un fichier"}
            </label>
            <input
              id="contract-file-input"
              type="file"
              accept="application/pdf,image/*"
              onChange={(e) => setFile(e.target.files?.[0] || null)}
              style={{ position: "absolute", width: 1, height: 1, opacity: 0, pointerEvents: "none" }}
            />
          </div>
        </div>
        <button onClick={handleAdd} disabled={saving} className="rounded-lg px-4 py-2 text-sm font-medium text-white flex items-center gap-2" style={{ background: INK }}>
          <Upload size={14} /> {saving ? "Enregistrement..." : "Ajouter le contrat"}
        </button>
      </div>
    </div>
  );
}

function CoursesTab({ courses, chapters, homework, documents, chapterDocuments, onAddCourse, onDeleteCourse, onAddChapter, onRemoveChapter, onUploadSummary, onRemoveSummary, onViewSummary, onAddChapterDoc, onRemoveChapterDoc, onViewChapterDoc, onAddHomework, onToggleHomework, onRemoveHomework, onAddDocument, onRemoveDocument, onViewDocument, onUploadHomeworkDoc, onRemoveHomeworkDoc, onViewHomeworkDoc }) {
  const [courseName, setCourseName] = useState("");
  const [openCourseId, setOpenCourseId] = useState(null);

  return (
    <div className="space-y-5">
      <div className="bg-white rounded-2xl p-5 md:p-6" style={{ border: "1px solid #e5e5e0" }}>
        <h2 className="text-lg font-semibold mb-4" style={{ color: INK }}>Mes cours</h2>
        <div className="space-y-2 mb-3">
          {courses.map((c) => {
            const courseChapters = chapters.filter((ch) => ch.course_id === c.id);
            const docs = documents.filter((d) => d.course_id === c.id);
            const isOpen = openCourseId === c.id;
            return (
              <div key={c.id} className="rounded-xl" style={{ border: "1px solid #e5e5e0" }}>
                <div className="w-full flex items-center justify-between px-3 py-2">
                  <button onClick={() => setOpenCourseId(isOpen ? null : c.id)} className="flex-1 text-left">
                    <span className="text-sm font-medium" style={{ color: INK }}>{c.name}</span>
                  </button>
                  <span className="text-xs px-2 py-0.5 rounded-full mr-2" style={{ background: `${c.color}22`, color: "#7A5A00" }}>
                    {courseChapters.length} chapitre{courseChapters.length !== 1 ? "s" : ""}
                  </span>
                  <button onClick={() => { if (confirm(`Supprimer le cours "${c.name}" et tout son contenu (chapitres, devoirs, documents) ?`)) onDeleteCourse(c.id); }}>
                    <Trash2 size={14} className="text-neutral-400" />
                  </button>
                </div>
                {isOpen && (
                  <div className="px-3 pb-3 pt-1 space-y-3" style={{ borderTop: "1px solid #f0f0ea" }}>
                    {courseChapters.map((ch) => (
                      <ChapterBlock
                        key={ch.id}
                        chapter={ch}
                        homework={homework.filter((h) => h.chapter_id === ch.id)}
                        docs={chapterDocuments.filter((d) => d.chapter_id === ch.id)}
                        onRemoveChapter={onRemoveChapter}
                        onUploadSummary={onUploadSummary}
                        onRemoveSummary={onRemoveSummary}
                        onViewSummary={onViewSummary}
                        onAddChapterDoc={onAddChapterDoc}
                        onRemoveChapterDoc={onRemoveChapterDoc}
                        onViewChapterDoc={onViewChapterDoc}
                        onAddHomework={onAddHomework}
                        onToggleHomework={onToggleHomework}
                        onRemoveHomework={onRemoveHomework}
                        onUploadHomeworkDoc={onUploadHomeworkDoc}
                        onRemoveHomeworkDoc={onRemoveHomeworkDoc}
                        onViewHomeworkDoc={onViewHomeworkDoc}
                      />
                    ))}
                    <AddChapter courseId={c.id} onAdd={onAddChapter} />
                    <div className="pt-2" style={{ borderTop: "1px solid #f0f0ea" }}>
                      <p className="text-xs font-semibold text-neutral-500 mb-1.5">Devoirs généraux du cours (hors chapitre)</p>
                      <div className="space-y-1.5 mb-1.5">
                        {homework.filter((h) => h.course_id === c.id && !h.chapter_id).map((h) => (
                          <HomeworkRow key={h.id} h={h} onToggle={onToggleHomework} onRemove={onRemoveHomework} onUploadDoc={onUploadHomeworkDoc} onRemoveDoc={onRemoveHomeworkDoc} onViewDoc={onViewHomeworkDoc} />
                        ))}
                      </div>
                      <GeneralHomeworkForm courseId={c.id} onAdd={onAddHomework} />
                    </div>
                    <div className="pt-2" style={{ borderTop: "1px solid #f0f0ea" }}>
                      <p className="text-xs font-semibold text-neutral-500 mb-2">Documents généraux du cours</p>
                      <CourseDocuments courseId={c.id} docs={docs} onAdd={onAddDocument} onRemove={onRemoveDocument} onView={onViewDocument} />
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
        <div className="flex gap-2">
          <input value={courseName} onChange={(e) => setCourseName(e.target.value)} placeholder="Nom du cours" className="border rounded-lg px-2 py-1.5 text-sm flex-1" />
          <button onClick={() => { if (courseName.trim()) { onAddCourse(courseName.trim()); setCourseName(""); } }} className="rounded-lg px-3 py-1.5 text-sm font-medium text-white" style={{ background: INK }}>Ajouter</button>
        </div>
      </div>
    </div>
  );
}

function ChapterBlock({ chapter, homework, docs, onRemoveChapter, onUploadSummary, onRemoveSummary, onViewSummary, onAddChapterDoc, onRemoveChapterDoc, onViewChapterDoc, onAddHomework, onToggleHomework, onRemoveHomework, onUploadHomeworkDoc, onRemoveHomeworkDoc, onViewHomeworkDoc }) {
  const [open, setOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [title, setTitle] = useState("");
  const [due, setDue] = useState("");

  return (
    <div className="rounded-lg" style={{ background: "#fafaf7", border: "1px solid #eee" }}>
      <div className="flex items-center gap-2 px-2.5 py-2">
        <button onClick={() => setOpen(!open)} className="flex-1 text-left text-sm font-medium" style={{ color: INK }}>{chapter.name}</button>
        <span className="text-xs text-neutral-400">{homework.filter((h) => !h.done).length} devoir(s)</span>
        <button onClick={() => onRemoveChapter(chapter.id)}><Trash2 size={12} className="text-neutral-400" /></button>
      </div>
      {open && (
        <div className="px-2.5 pb-2.5 space-y-3">
          <div>
            <p className="text-xs font-semibold text-neutral-500 mb-1">Résumé du chapitre</p>
            {chapter.summary_path ? (
              <div className="flex items-center gap-2">
                <button onClick={() => onViewSummary(chapter.summary_path)} className="text-xs px-2 py-1 rounded-lg font-medium" style={{ background: `${TEAL}22`, color: TEAL }}>Voir le résumé</button>
                <button onClick={() => onRemoveSummary(chapter.id, chapter.summary_path)}><Trash2 size={11} className="text-neutral-400" /></button>
              </div>
            ) : (
              <label className="flex items-center gap-1.5 border rounded-lg px-2 py-1 text-xs cursor-pointer w-fit" style={{ borderColor: "#ccc", background: "#fff", color: "#666" }}>
                <Upload size={11} /> {uploading ? "Envoi..." : "Ajouter un résumé"}
                <input type="file" onChange={async (e) => { const f = e.target.files?.[0]; if (!f) return; setUploading(true); await onUploadSummary(chapter.id, f); setUploading(false); }} style={{ position: "absolute", width: 1, height: 1, opacity: 0, pointerEvents: "none" }} />
              </label>
            )}
          </div>
          <div>
            <p className="text-xs font-semibold text-neutral-500 mb-1">Documents du chapitre</p>
            <CourseDocuments courseId={chapter.id} docs={docs} onAdd={onAddChapterDoc} onRemove={onRemoveChapterDoc} onView={onViewChapterDoc} compact />
          </div>
          <div>
            <p className="text-xs font-semibold text-neutral-500 mb-1">Devoirs</p>
            <div className="space-y-1.5 mb-1.5">
              {homework.length === 0 && <p className="text-xs text-neutral-400">Aucun devoir.</p>}
              {homework.map((h) => (
                <HomeworkRow key={h.id} h={h} onToggle={onToggleHomework} onRemove={onRemoveHomework} onUploadDoc={onUploadHomeworkDoc} onRemoveDoc={onRemoveHomeworkDoc} onViewDoc={onViewHomeworkDoc} />
              ))}
            </div>
            <div className="flex flex-wrap gap-1.5">
              <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Titre du devoir" className="border rounded-lg px-2 py-1 text-xs flex-1 min-w-[90px]" />
              <input type="date" value={due} onChange={(e) => setDue(e.target.value)} className="border rounded-lg px-2 py-1 text-xs" />
              <button onClick={() => { if (title.trim() && due) { onAddHomework({ title, chapter_id: chapter.id, due_date: due, done: false }); setTitle(""); setDue(""); } else { alert("Titre et date limite sont obligatoires."); } }} className="rounded-lg px-2 py-1 text-xs font-medium text-white" style={{ background: INK }}>Ajouter</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function HomeworkRow({ h, onToggle, onRemove, onUploadDoc, onRemoveDoc, onViewDoc }) {
  const [uploading, setUploading] = useState(false);
  return (
    <div className="rounded-lg px-2 py-1.5" style={{ background: h.done ? "#eee" : "#fff" }}>
      <label className="flex items-center gap-2 text-xs">
        <input type="checkbox" checked={h.done} onChange={() => onToggle(h.id, h.done)} />
        <span className={h.done ? "line-through text-neutral-400" : ""}>{h.title}</span>
        <span className="text-neutral-400 ml-auto">{h.due_date}</span>
        <button onClick={() => onRemove(h.id)}><Trash2 size={10} className="text-neutral-400" /></button>
      </label>
      <div className="mt-1 ml-5">
        {h.document_path ? (
          <div className="flex items-center gap-1.5">
            <button onClick={() => onViewDoc(h.document_path)} className="text-[11px] px-1.5 py-0.5 rounded font-medium" style={{ background: `${TEAL}22`, color: TEAL }}>Voir le document</button>
            <button onClick={() => onRemoveDoc(h.id, h.document_path)}><Trash2 size={9} className="text-neutral-400" /></button>
          </div>
        ) : (
          <label className="flex items-center gap-1 text-[11px] cursor-pointer w-fit" style={{ color: "#999" }}>
            <Upload size={9} /> {uploading ? "Envoi..." : "+ document"}
            <input type="file" onChange={async (e) => { const f = e.target.files?.[0]; if (!f) return; setUploading(true); await onUploadDoc(h.id, f); setUploading(false); }} style={{ position: "absolute", width: 1, height: 1, opacity: 0, pointerEvents: "none" }} />
          </label>
        )}
      </div>
    </div>
  );
}

function AddChapter({ courseId, onAdd }) {
  const [name, setName] = useState("");
  return (
    <div className="flex gap-1.5">
      <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nom du chapitre" className="border rounded-lg px-2 py-1.5 text-xs flex-1" />
      <button onClick={() => { if (name.trim()) { onAdd(courseId, name.trim()); setName(""); } }} className="rounded-lg px-2.5 py-1.5 text-xs font-medium" style={{ background: `${MARKER}33`, color: "#7A5A00" }}>+ Chapitre</button>
    </div>
  );
}

function GeneralHomeworkForm({ courseId, onAdd }) {
  const [title, setTitle] = useState("");
  const [due, setDue] = useState("");
  return (
    <div className="flex flex-wrap gap-1.5">
      <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Titre du devoir" className="border rounded-lg px-2 py-1 text-xs flex-1 min-w-[90px]" />
      <input type="date" value={due} onChange={(e) => setDue(e.target.value)} className="border rounded-lg px-2 py-1 text-xs" />
      <button
        onClick={() => { if (title.trim() && due) { onAdd({ title, course_id: courseId, chapter_id: null, due_date: due, done: false }); setTitle(""); setDue(""); } else { alert("Titre et date limite sont obligatoires."); } }}
        className="rounded-lg px-2 py-1 text-xs font-medium text-white"
        style={{ background: INK }}
      >
        Ajouter
      </button>
    </div>
  );
}

function CourseDocuments({ courseId, docs, onAdd, onRemove, onView }) {
  const [uploading, setUploading] = useState(false);

  return (
    <div className="px-3 pb-3 pt-1 space-y-2" style={{ borderTop: "1px solid #f0f0ea" }}>
      {docs.length === 0 && <p className="text-xs text-neutral-400">Aucun document pour ce cours.</p>}
      {docs.map((d, i) => (
        <div key={d.id} className="flex items-center gap-2 text-xs rounded-lg px-2 py-1.5" style={{ background: "#fafaf7" }}>
          <span className="font-mono text-neutral-400">{i + 1}.</span>
          <button onClick={() => onView(d.file_path)} className="flex-1 text-left hover:underline" style={{ color: INK }}>{d.name}</button>
          <button onClick={() => onRemove(d.id, d.file_path)}><Trash2 size={12} className="text-neutral-400" /></button>
        </div>
      ))}
      <label
        htmlFor={`doc-input-${courseId}`}
        className="flex items-center gap-2 border rounded-lg px-2.5 py-1.5 text-xs cursor-pointer w-fit"
        style={{ borderColor: "#ccc", background: "#fafafa", color: "#666" }}
      >
        <Upload size={12} /> {uploading ? "Envoi..." : "Ajouter un document"}
      </label>
      <input
        id={`doc-input-${courseId}`}
        type="file"
        onChange={async (e) => {
          const f = e.target.files?.[0];
          if (!f) return;
          setUploading(true);
          await onAdd(courseId, f.name, f);
          setUploading(false);
        }}
        style={{ position: "absolute", width: 1, height: 1, opacity: 0, pointerEvents: "none" }}
      />
    </div>
  );
}

function CalendarTab({ events, onAddEvent, onRemoveEvent, calendarUrl, onSyncUrl, calendarPdfPath, onUploadPdf, onRemovePdf, onViewPdf }) {
  const [title, setTitle] = useState("");
  const [date, setDate] = useState("");
  const [url, setUrl] = useState(calendarUrl || "");
  const [syncing, setSyncing] = useState(false);
  const [syncError, setSyncError] = useState("");
  const [syncSuccess, setSyncSuccess] = useState("");
  const [pdfUploading, setPdfUploading] = useState(false);

  useEffect(() => setUrl(calendarUrl || ""), [calendarUrl]);

  async function handleSync() {
    if (!url.trim()) return;
    setSyncing(true);
    setSyncError("");
    setSyncSuccess("");
    try {
      const res = await fetch("/api/sync-calendar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: url.trim() }),
      });
      const json = await res.json();
      if (!res.ok) {
        setSyncError(json.error || "Erreur lors de la synchronisation.");
      } else {
        setSyncSuccess(`${json.events.length} événement(s) synchronisé(s) !`);
        onSyncUrl();
      }
    } catch (e) {
      setSyncError("Erreur réseau, réessaie.");
    }
    setSyncing(false);
  }

  return (
    <div className="space-y-5">
      <div className="bg-white rounded-2xl p-5 md:p-6" style={{ border: "1px solid #e5e5e0" }}>
        <h2 className="text-lg font-semibold mb-2" style={{ color: INK }}>Calendrier universitaire</h2>
        <p className="text-xs text-neutral-500 mb-3">
          Colle ici le lien (URL) du calendrier de ton université — demande le service scolarité si tu ne l'as pas, il ressemble souvent à un lien qui finit par ".ics".
        </p>
        <div className="flex flex-wrap gap-2 mb-2">
          <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://mon-universite.fr/calendrier.ics" className="border rounded-lg px-2 py-1.5 text-sm flex-1 min-w-[200px]" />
          <button onClick={handleSync} disabled={syncing} className="rounded-lg px-4 py-1.5 text-sm font-medium text-white" style={{ background: INK }}>
            {syncing ? "Synchronisation..." : "Synchroniser"}
          </button>
        </div>
        {syncError && <p className="text-xs" style={{ color: "#FF6B57" }}>{syncError}</p>}
        {syncSuccess && <p className="text-xs" style={{ color: TEAL }}>{syncSuccess}</p>}
      </div>

      <div className="bg-white rounded-2xl p-5 md:p-6" style={{ border: "1px solid #e5e5e0" }}>
        <h2 className="text-lg font-semibold mb-2" style={{ color: INK }}>PDF résumé de l'année universitaire</h2>
        <p className="text-xs text-neutral-500 mb-3">Un seul fichier — chaque nouvel envoi remplace le précédent.</p>
        {calendarPdfPath ? (
          <div className="flex items-center gap-2">
            <button onClick={onViewPdf} className="text-xs px-2.5 py-1.5 rounded-lg font-medium" style={{ background: `${TEAL}22`, color: TEAL }}>Voir le PDF</button>
            <button onClick={onRemovePdf}><Trash2 size={14} className="text-neutral-400" /></button>
            <label htmlFor="pdf-summary-input" className="text-xs px-2.5 py-1.5 rounded-lg font-medium cursor-pointer ml-2" style={{ background: "#f0f0ea", color: INK }}>
              Remplacer
            </label>
          </div>
        ) : (
          <label htmlFor="pdf-summary-input" className="flex items-center gap-2 border rounded-lg px-3 py-2 text-sm cursor-pointer w-fit" style={{ borderColor: "#ccc", background: "#fafafa", color: "#666" }}>
            <Upload size={14} /> {pdfUploading ? "Envoi..." : "Choisir un fichier PDF"}
          </label>
        )}
        <input
          id="pdf-summary-input"
          type="file"
          accept="application/pdf"
          onChange={async (e) => {
            const f = e.target.files?.[0];
            if (!f) return;
            setPdfUploading(true);
            await onUploadPdf(f);
            setPdfUploading(false);
          }}
          style={{ position: "absolute", width: 1, height: 1, opacity: 0, pointerEvents: "none" }}
        />
      </div>

      <div className="bg-white rounded-2xl p-5 md:p-6" style={{ border: "1px solid #e5e5e0" }}>
        <h2 className="text-lg font-semibold mb-2" style={{ color: INK }}>Ou importer un fichier .ics téléchargé</h2>
        <p className="text-xs text-neutral-500 mb-3">
          Si ton université propose un bouton "Télécharger le calendrier" plutôt qu'un lien, utilise ça : télécharge le fichier, choisis-le ci-dessous.
        </p>
        <FileIcsImport events={events} onAddEvent={onAddEvent} onImported={onSyncUrl} />
      </div>

      <div className="bg-white rounded-2xl p-5 md:p-6" style={{ border: "1px solid #e5e5e0" }}>
        <h2 className="text-lg font-semibold mb-4" style={{ color: INK }}>Mes événements</h2>
        <div className="space-y-2 mb-4">
          {events.map((e) => (
            <div key={e.id} className="flex items-center gap-2 text-sm rounded-lg px-2 py-1.5" style={{ border: "1px solid #e5e5e0" }}>
              <span>{e.title}</span>
              <span className="text-xs text-neutral-400 ml-auto font-mono">{e.event_date || "date libre"}</span>
              <button onClick={() => onRemoveEvent(e.id)}><Trash2 size={12} className="text-neutral-400" /></button>
            </div>
          ))}
        </div>
        <div className="flex flex-wrap gap-2">
          <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Ajouter un événement manuellement" className="border rounded-lg px-2 py-1.5 text-sm flex-1 min-w-[140px]" />
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="border rounded-lg px-2 py-1.5 text-sm" />
          <button onClick={() => { if (title.trim()) { onAddEvent(title, date); setTitle(""); setDate(""); } }} className="rounded-lg px-3 py-1.5 text-sm font-medium text-white" style={{ background: INK }}>Ajouter</button>
        </div>
      </div>
    </div>
  );
}

function FileIcsImport({ onAddEvent, onImported }) {
  const [fileName, setFileName] = useState("");
  const [status, setStatus] = useState("");

  async function handleFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    setStatus("Lecture du fichier...");
    const text = await file.text();

    const lines = text.split(/\r?\n/);
    const parsed = [];
    let cur = {};
    lines.forEach((line) => {
      if (line.startsWith("BEGIN:VEVENT")) cur = {};
      if (line.startsWith("SUMMARY:")) cur.title = line.replace("SUMMARY:", "").trim();
      if (line.startsWith("DTSTART")) {
        const raw = line.split(":")[1]?.trim();
        if (raw) {
          const y = raw.slice(0, 4), m = raw.slice(4, 6), d = raw.slice(6, 8);
          cur.date = `${y}-${m}-${d}`;
        }
      }
      if (line.startsWith("END:VEVENT") && cur.title) { parsed.push({ ...cur }); cur = {}; }
    });

    if (parsed.length === 0) {
      setStatus("Aucun événement trouvé dans ce fichier.");
      return;
    }
    setStatus(`Import de ${parsed.length} événement(s)...`);
    for (const ev of parsed) {
      await onAddEvent(ev.title, ev.date);
    }
    onImported();
    setStatus(`${parsed.length} événement(s) importé(s) !`);
  }

  return (
    <div>
      <label
        htmlFor="ics-file-input"
        className="flex items-center gap-2 border rounded-lg px-3 py-2 text-sm cursor-pointer w-fit"
        style={{ borderColor: "#ccc", background: fileName ? `${TEAL}11` : "#fafafa", color: fileName ? TEAL : "#666" }}
      >
        <Upload size={14} />
        {fileName || "Choisir un fichier .ics"}
      </label>
      <input id="ics-file-input" type="file" accept=".ics,text/calendar" onChange={handleFile} style={{ position: "absolute", width: 1, height: 1, opacity: 0, pointerEvents: "none" }} />
      {status && <p className="text-xs mt-2" style={{ color: TEAL }}>{status}</p>}
    </div>
  );
}

function LinksTab({ links, onAdd, onRemove }) {
  const [name, setName] = useState("");
  const [url, setUrl] = useState("");

  function handleAdd() {
    if (!name.trim() || !url.trim()) return;
    onAdd(name.trim(), url.trim());
    setName("");
    setUrl("");
  }

  return (
    <div className="bg-white rounded-2xl p-5 md:p-6" style={{ border: "1px solid #e5e5e0" }}>
      <h2 className="text-lg font-semibold mb-2" style={{ color: INK }}>Sites importants</h2>
      <p className="text-xs text-neutral-500 mb-4">
        Enregistre les liens que tu utilises souvent (ENT, plateforme de cours, messagerie, banque, CAF...) pour les rouvrir en un clic.
      </p>

      <div className="space-y-2 mb-4">
        {links.length === 0 && <p className="text-sm text-neutral-400">Aucun site enregistré pour l'instant.</p>}
        {links.map((l) => (
          <div key={l.id} className="flex items-center gap-2 text-sm rounded-lg px-3 py-2" style={{ border: "1px solid #e5e5e0" }}>
            <a
              href={l.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 flex-1 font-medium hover:underline"
              style={{ color: INK }}
            >
              <ExternalLink size={14} style={{ color: TEAL }} />
              {l.name}
            </a>
            <button onClick={() => onRemove(l.id)}><Trash2 size={14} className="text-neutral-400" /></button>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap gap-2">
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nom (ex: ENT université)" className="border rounded-lg px-2 py-1.5 text-sm flex-1 min-w-[140px]" />
        <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="Lien du site (ex: ent.univ-paris13.fr)" className="border rounded-lg px-2 py-1.5 text-sm flex-1 min-w-[180px]" />
        <button onClick={handleAdd} className="rounded-lg px-3 py-1.5 text-sm font-medium text-white flex items-center gap-1" style={{ background: INK }}>
          <Plus size={14} /> Ajouter
        </button>
      </div>
    </div>
  );
}

function TasksTab({ tasks, onAdd, onToggle, onRemove }) {
  const [text, setText] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");

  function handleAdd() {
    if (!text.trim()) return;
    onAdd(text.trim(), date, time);
    setText("");
    setDate("");
    setTime("");
  }

  const sorted = [...tasks].sort((a, b) => {
    if (a.done !== b.done) return a.done ? 1 : -1;
    return (a.task_date || "9999-99-99").localeCompare(b.task_date || "9999-99-99");
  });

  return (
    <div className="bg-white rounded-2xl p-5 md:p-6" style={{ border: "1px solid #e5e5e0" }}>
      <h2 className="text-lg font-semibold mb-4" style={{ color: INK }}>Tâches personnelles</h2>

      <div className="space-y-2 mb-4">
        {tasks.length === 0 && <p className="text-sm text-neutral-400">Aucune tâche pour l'instant.</p>}
        {sorted.map((t) => (
          <label key={t.id} className="flex items-start gap-2 text-sm rounded-lg px-3 py-2" style={{ background: t.done ? "#f4f4ef" : "#fff", border: "1px solid #e5e5e0" }}>
            <input type="checkbox" checked={t.done} onChange={() => onToggle(t.id, t.done)} className="mt-0.5" />
            <div className="flex-1">
              <p className={t.done ? "line-through text-neutral-400" : ""}>{t.text}</p>
              {(t.task_date || t.task_time) && (
                <p className="text-xs text-neutral-400 font-mono mt-0.5">
                  {t.task_date ? new Date(t.task_date + "T00:00:00").toLocaleDateString("fr-FR") : ""} {t.task_time || ""}
                </p>
              )}
            </div>
            <button onClick={() => onRemove(t.id)}><Trash2 size={12} className="text-neutral-400" /></button>
          </label>
        ))}
      </div>

      <div className="space-y-2">
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Décris ta tâche..."
          rows={2}
          className="w-full border rounded-lg px-2 py-1.5 text-sm"
        />
        <div className="flex flex-wrap gap-2">
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="border rounded-lg px-2 py-1.5 text-sm" />
          <input type="time" value={time} onChange={(e) => setTime(e.target.value)} className="border rounded-lg px-2 py-1.5 text-sm" />
          <button onClick={handleAdd} className="rounded-lg px-3 py-1.5 text-sm font-medium text-white flex items-center gap-1" style={{ background: INK }}>
            <Plus size={14} /> Ajouter
          </button>
        </div>
      </div>
    </div>
  );
}

function FeedbackTab({ feedback, onAdd }) {
  const [text, setText] = useState("");
  const [sent, setSent] = useState(false);

  function handleSend() {
    if (!text.trim()) return;
    onAdd(text.trim());
    setText("");
    setSent(true);
    setTimeout(() => setSent(false), 3000);
  }

  return (
    <div className="bg-white rounded-2xl p-5 md:p-6" style={{ border: "1px solid #e5e5e0" }}>
      <h2 className="text-lg font-semibold mb-2" style={{ color: INK }}>Suggestions & bugs</h2>
      <p className="text-xs text-neutral-500 mb-4">
        Un bug, une idée, un truc qui te gêne ? Écris-le ici, ça remonte directement au développeur.
      </p>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={4}
        placeholder="Décris ce que tu as remarqué..."
        className="w-full border rounded-lg px-2 py-1.5 text-sm mb-2"
      />
      <button onClick={handleSend} className="rounded-lg px-4 py-2 text-sm font-medium text-white" style={{ background: INK }}>
        Envoyer
      </button>
      {sent && <span className="ml-3 text-xs" style={{ color: TEAL }}>Envoyé, merci ! 🙌</span>}

      {feedback.length > 0 && (
        <div className="mt-6 pt-4 space-y-2" style={{ borderTop: "1px solid #f0f0ea" }}>
          <p className="text-xs font-semibold text-neutral-500">Tes suggestions envoyées</p>
          {feedback.map((f) => (
            <p key={f.id} className="text-xs rounded-lg px-2.5 py-1.5" style={{ background: "#fafaf7", color: "#666" }}>{f.text}</p>
          ))}
        </div>
      )}
    </div>
  );
}

const FAQ_DATA = [
  {
    category: "💼 Travail étudiant",
    items: [
      {
        q: "Combien d'heures ai-je le droit de travailler par an ?",
        a: "Pour les étudiants étrangers hors UE/EEE/Suisse, la limite légale est de 964 heures par an (environ 60% d'un temps plein). Pour les étudiants français ou UE, il n'y a pas de plafond légal spécifique, mais le nombre d'heures peut affecter les bourses ou allocations.",
        link: "https://www.service-public.fr/particuliers/vosdroits/F2725",
      },
      {
        q: "Quel salaire minimum dois-je toucher ?",
        a: "Le SMIC horaire brut est le minimum légal, quel que soit le contrat (CDD, CDI, contrat étudiant). Vérifie ta fiche de paie régulièrement.",
        link: "https://www.service-public.fr/particuliers/vosdroits/F2300",
      },
    ],
  },
  {
    category: "🏛️ Titre de séjour",
    items: [
      {
        q: "Comment renouveler mon titre de séjour étudiant ?",
        a: "La demande se fait en ligne sur le site de l'Administration Numérique des Étrangers en France (ANEF), généralement 2 à 4 mois avant l'expiration. Prévois large : les délais varient selon les préfectures.",
        link: "https://administration-etrangers-en-france.interieur.gouv.fr",
      },
      {
        q: "Que faire si mon titre de séjour expire bientôt et que je n'ai pas de rendez-vous ?",
        a: "Contacte ta préfecture au plus vite et garde une preuve de ta démarche (récépissé de dépôt de dossier) — ça te permet de rester en situation régulière pendant l'instruction du dossier.",
        link: "https://www.service-public.fr/particuliers/vosdroits/N110",
      },
    ],
  },
  {
    category: "🏠 Logement (CROUS / CAF)",
    items: [
      {
        q: "Comment faire une demande de logement CROUS ?",
        a: "La demande se fait via le Dossier Social Étudiant (DSE) sur le site Messervices.etudiant.gouv.fr, généralement entre janvier et mai pour la rentrée suivante.",
        link: "https://www.etudiant.gouv.fr/fr/trouver-un-logement-855",
      },
      {
        q: "Ai-je droit aux APL/ALS de la CAF ?",
        a: "La plupart des étudiants, y compris étrangers avec un titre de séjour valide, peuvent en bénéficier. Fais une simulation en ligne pour connaître ton montant estimé avant de déposer le dossier.",
        link: "https://www.caf.fr/allocataires/aides-et-demarches/droits-et-prestations/logement/les-aides-au-logement",
      },
    ],
  },
  {
    category: "🏥 Sécurité sociale & santé",
    items: [
      {
        q: "Comment m'inscrire à la sécurité sociale étudiante ?",
        a: "Depuis 2019, l'affiliation est automatique via le régime général au moment de ton inscription universitaire (plus besoin de cotisation spécifique étudiante). Vérifie ton statut sur ameli.fr et crée ton compte.",
        link: "https://www.ameli.fr/etudiant",
      },
      {
        q: "Comment avoir une mutuelle complémentaire ?",
        a: "La sécu de base ne rembourse pas tout — une mutuelle étudiante (souvent à tarif réduit) complète les remboursements. Compare les offres avant de choisir.",
      },
    ],
  },
  {
    category: "🏦 Banque",
    items: [
      {
        q: "Quels documents pour ouvrir un compte bancaire en France ?",
        a: "Généralement : passeport ou carte d'identité, justificatif de domicile (quittance de loyer, facture), certificat de scolarité, et parfois titre de séjour. Chaque banque peut demander des pièces légèrement différentes — appelle avant de te déplacer.",
      },
      {
        q: "Banque en ligne ou banque traditionnelle ?",
        a: "Les banques en ligne sont souvent gratuites et rapides à ouvrir (utile en attendant un logement fixe), mais une banque physique peut être plus pratique pour les démarches nécessitant un conseiller (prêt, etc.).",
      },
    ],
  },
];

function FaqTab() {
  const [openIndex, setOpenIndex] = useState(null);

  return (
    <div className="space-y-5">
      <div className="bg-white rounded-2xl p-5 md:p-6" style={{ border: "1px solid #e5e5e0" }}>
        <h2 className="text-lg font-semibold mb-1" style={{ color: INK }}>FAQ étudiants</h2>
        <p className="text-xs text-neutral-500">
          Questions fréquentes, notamment pour les étudiants internationaux. Pour toute démarche officielle urgente ou complexe, vérifie toujours sur le site officiel lié ou auprès du service concerné — ces réponses sont indicatives, pas un conseil juridique.
        </p>
      </div>

      {FAQ_DATA.map((cat, ci) => (
        <div key={ci} className="bg-white rounded-2xl p-5 md:p-6" style={{ border: "1px solid #e5e5e0" }}>
          <h3 className="text-sm font-semibold mb-3" style={{ color: INK }}>{cat.category}</h3>
          <div className="space-y-2">
            {cat.items.map((item, ii) => {
              const key = `${ci}-${ii}`;
              const isOpen = openIndex === key;
              return (
                <div key={key} className="rounded-lg" style={{ background: "#fafaf7", border: "1px solid #eee" }}>
                  <button onClick={() => setOpenIndex(isOpen ? null : key)} className="w-full text-left px-3 py-2 text-sm font-medium" style={{ color: INK }}>
                    {item.q}
                  </button>
                  {isOpen && (
                    <div className="px-3 pb-3 text-xs text-neutral-600 space-y-1.5">
                      <p>{item.a}</p>
                      {item.link && (
                        <a href={item.link} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 font-medium" style={{ color: TEAL }}>
                          <ExternalLink size={11} /> Voir la source officielle
                        </a>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

const HELP_SECTIONS = [
  {
    title: "📲 Installer l'application sur ton téléphone",
    text: "Ce n'est pas à télécharger depuis un store, mais tu peux l'ajouter à ton écran d'accueil comme une vraie app : sur Android (Chrome), menu ⋮ → 'Installer l'application' ou 'Ajouter à l'écran d'accueil'. Sur iPhone (Safari), bouton Partager → 'Sur l'écran d'accueil'. Une icône apparaîtra, et l'app s'ouvrira en plein écran sans barre de navigateur.",
  },
  {
    title: "🏠 Accueil & Travail",
    text: "En haut, tu vois un résumé rapide (heures restantes, prochains devoirs, événements à venir). Plus bas, la carte de pointage calcule automatiquement tes heures travaillées depuis une date de départ que tu choisis, en fonction de tes créneaux hebdomadaires. ⚠️ Important : un créneau ajouté dans 'Créneaux de travail' est RÉCURRENT — si tu ajoutes 'Lundi 18h-22h', ça compte automatiquement CHAQUE lundi, semaine après semaine, tant que le créneau existe. Si tu as travaillé un jour exceptionnel (une seule fois, pas toutes les semaines), n'ajoute pas de créneau récurrent : utilise plutôt 'Ajouter des heures pour un jour précis' plus bas, ou l'ajustement rapide (+/-) directement sur la carte de pointage.",
  },
  {
    title: "📄 Contrats",
    text: "Ajoute chacun de tes contrats de travail (un par job), avec la date de signature, ton taux horaire, et le PDF signé si tu l'as. Tu peux modifier ou supprimer un contrat à tout moment en cliquant dessus.",
  },
  {
    title: "📚 Études",
    text: "Crée un cours, puis à l'intérieur des chapitres. Chaque chapitre peut avoir un résumé (PDF), des documents, et ses propres devoirs avec une date limite obligatoire — ça t'évite d'oublier une échéance.",
  },
  {
    title: "📅 Calendrier universitaire",
    text: "Colle le lien de ton université si tu en as un (ça synchronise automatiquement), ou importe le fichier .ics téléchargé. Tu peux aussi ajouter un PDF résumé de l'année.",
  },
  {
    title: "🔗 Liens utiles",
    text: "Sauvegarde les sites que tu utilises souvent (ENT, CAF, banque...) pour les rouvrir en un clic.",
  },
  {
    title: "✅ Tâches personnelles",
    text: "Pour tout ce qui n'est ni un devoir ni du travail — courses, rendez-vous, démarches administratives...",
  },
  {
    title: "💡 Suggestions",
    text: "Un bug ou une idée ? Écris-le ici, ça remonte directement au développeur.",
  },
];

function HelpTab() {
  return (
    <div className="space-y-3">
      <div className="bg-white rounded-2xl p-5 md:p-6" style={{ border: "1px solid #e5e5e0" }}>
        <h2 className="text-lg font-semibold mb-1" style={{ color: INK }}>Comment ça marche</h2>
        <p className="text-xs text-neutral-500">Un guide rapide pour chaque partie de l'application.</p>
      </div>
      {HELP_SECTIONS.map((s, i) => (
        <div key={i} className="bg-white rounded-2xl p-4 md:p-5" style={{ border: "1px solid #e5e5e0" }}>
          <h3 className="text-sm font-semibold mb-1.5" style={{ color: INK }}>{s.title}</h3>
          <p className="text-xs text-neutral-600 leading-relaxed">{s.text}</p>
        </div>
      ))}
    </div>
  );
}

function OnboardingModal() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const seen = window.localStorage.getItem("carnet_onboarding_seen");
    if (!seen) setShow(true);
  }, []);

  function dismiss() {
    window.localStorage.setItem("carnet_onboarding_seen", "1");
    setShow(false);
  }

  if (!show) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.5)" }}>
      <div className="bg-white rounded-2xl p-6 max-w-md w-full">
        <h2 className="text-xl font-bold mb-3" style={{ color: INK }}>Bienvenue sur Carnet Étudiant 👋</h2>
        <div className="text-sm text-neutral-600 space-y-2 mb-5">
          <p>Voici l'essentiel pour bien démarrer :</p>
          <p>💼 <strong>Travail</strong> — ajoute tes créneaux, ton compteur d'heures se met à jour tout seul</p>
          <p>📄 <strong>Contrats</strong> — un contrat par job, avec le PDF signé si possible</p>
          <p>📚 <strong>Études</strong> — organise par cours → chapitres → devoirs (date limite obligatoire !)</p>
          <p>Besoin d'aide plus tard ? Va dans le menu ☰ → <strong>🧭 Aide</strong>.</p>
        </div>
        <button onClick={dismiss} className="w-full rounded-lg px-4 py-2.5 text-sm font-medium text-white" style={{ background: INK }}>
          C'est parti !
        </button>
      </div>
    </div>
  );
}

const DOC_CATEGORIES = ["Administratif", "Personnel", "Identité", "Santé", "Autre"];

function daysUntil(dateStr) {
  if (!dateStr) return null;
  const target = new Date(dateStr + "T00:00:00");
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  return Math.round((target - now) / (1000 * 60 * 60 * 24));
}

function ExpirationBadge({ dateStr }) {
  if (!dateStr) return null;
  const days = daysUntil(dateStr);
  let style = { background: `${TEAL}22`, color: TEAL };
  let label = `Expire le ${new Date(dateStr + "T00:00:00").toLocaleDateString("fr-FR")}`;
  if (days < 0) { style = { background: "#FF6B5722", color: "#FF6B57" }; label = "Expiré"; }
  else if (days <= 60) { style = { background: "#FF6B5722", color: "#FF6B57" }; label = `Expire dans ${days}j`; }
  else if (days <= 120) { style = { background: `${MARKER}33`, color: "#7A5A00" }; label = `Expire dans ${days}j`; }
  return <span className="text-[10px] px-1.5 py-0.5 rounded-full font-medium flex-shrink-0" style={style}>{label}</span>;
}

function PersonalDocumentsTab({ documents, onAdd, onRemove, onView }) {
  const [name, setName] = useState("");
  const [category, setCategory] = useState(DOC_CATEGORIES[0]);
  const [file, setFile] = useState(null);
  const [expiration, setExpiration] = useState("");
  const [uploading, setUploading] = useState(false);
  const [filter, setFilter] = useState("Tous");

  async function handleAdd() {
    if (!file) return;
    setUploading(true);
    await onAdd(name.trim(), category, file, expiration);
    setName("");
    setFile(null);
    setExpiration("");
    setUploading(false);
  }

  const filtered = filter === "Tous" ? documents : documents.filter((d) => d.category === filter);

  return (
    <div className="space-y-5">
      <div className="bg-white rounded-2xl p-5 md:p-6" style={{ border: "1px solid #e5e5e0" }}>
        <h2 className="text-lg font-semibold mb-1" style={{ color: INK }}>Documents importants</h2>
        <p className="text-xs text-neutral-500 mb-4">
          Un espace pour tes documents administratifs et personnels (carte d'identité, titre de séjour, justificatifs, attestations...), classés par catégorie.
        </p>

        <div className="flex flex-wrap gap-1.5 mb-4">
          {["Tous", ...DOC_CATEGORIES].map((c) => (
            <button
              key={c}
              onClick={() => setFilter(c)}
              className="text-xs px-2.5 py-1 rounded-full font-medium"
              style={{ background: filter === c ? INK : "#f0f0ea", color: filter === c ? PAPER : "#666" }}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="space-y-2 mb-5">
          {filtered.length === 0 && <p className="text-sm text-neutral-400">Aucun document ici pour l'instant.</p>}
          {filtered.map((d) => (
            <div key={d.id} className="flex items-center gap-2 text-sm rounded-lg px-3 py-2 flex-wrap" style={{ border: "1px solid #e5e5e0" }}>
              <span className="text-xs px-2 py-0.5 rounded-full flex-shrink-0" style={{ background: `${MARKER}33`, color: "#7A5A00" }}>{d.category}</span>
              <button onClick={() => onView(d.file_path)} className="flex-1 text-left hover:underline flex items-center gap-1 min-w-[100px]" style={{ color: INK }}>
                👁️ Voir — {d.name}
              </button>
              <ExpirationBadge dateStr={d.expiration_date} />
              <button onClick={() => onRemove(d.id, d.file_path)}><Trash2 size={14} className="text-neutral-400" /></button>
            </div>
          ))}
        </div>

        <div className="pt-4" style={{ borderTop: "1px solid #f0f0ea" }}>
          <p className="text-xs font-semibold text-neutral-500 mb-2">Ajouter un document</p>
          <div className="grid md:grid-cols-2 gap-2 mb-2">
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nom (ex: Carte d'identité)" className="border rounded-lg px-2 py-1.5 text-sm" />
            <select value={category} onChange={(e) => setCategory(e.target.value)} className="border rounded-lg px-2 py-1.5 text-sm">
              {DOC_CATEGORIES.map((c) => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div className="mb-2">
            <label className="text-xs text-neutral-500 block mb-1">Date d'expiration (optionnel)</label>
            <input type="date" value={expiration} onChange={(e) => setExpiration(e.target.value)} className="border rounded-lg px-2 py-1.5 text-sm" />
          </div>
          <label
            htmlFor="personal-doc-input"
            className="flex items-center gap-2 border rounded-lg px-3 py-2 text-sm cursor-pointer w-fit mb-2"
            style={{ borderColor: "#ccc", background: file ? `${TEAL}11` : "#fafafa", color: file ? TEAL : "#666" }}
          >
            <Upload size={14} /> {file ? file.name : "Choisir un fichier"}
          </label>
          <input id="personal-doc-input" type="file" onChange={(e) => setFile(e.target.files?.[0] || null)} style={{ position: "absolute", width: 1, height: 1, opacity: 0, pointerEvents: "none" }} />
          <div>
            <button onClick={handleAdd} disabled={uploading || !file} className="rounded-lg px-4 py-2 text-sm font-medium text-white" style={{ background: INK, opacity: uploading || !file ? 0.5 : 1 }}>
              {uploading ? "Envoi..." : "Ajouter"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
