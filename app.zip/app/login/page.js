'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [mode, setMode] = useState('signin') // 'signin' ou 'signup'
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    if (mode === 'signup') {
      const { error } = await supabase.auth.signUp({ email, password })
      if (error) {
        setError(error.message)
      } else {
        setError('Compte créé ! Vérifie tes emails pour confirmer, puis connecte-toi.')
        setMode('signin')
      }
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email, password })
      if (error) {
        setError(error.message)
      } else {
        router.push('/')
        router.refresh()
      }
    }
    setLoading(false)
  }

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: '#F2F3ED', padding: '20px' }}>
      <form onSubmit={handleSubmit} style={{ background: 'white', padding: '2rem', borderRadius: '1rem', width: '320px', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#14162B' }}>
          {mode === 'signin' ? 'Connexion' : 'Créer un compte'}
        </h1>

        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          style={{ padding: '0.6rem', borderRadius: '0.5rem', border: '1px solid #ddd' }}
        />
        <input
          type="password"
          placeholder="Mot de passe"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          minLength={6}
          style={{ padding: '0.6rem', borderRadius: '0.5rem', border: '1px solid #ddd' }}
        />

        {error && <p style={{ color: '#FF6B57', fontSize: '0.85rem' }}>{error}</p>}

        <button
          type="submit"
          disabled={loading}
          style={{ padding: '0.7rem', borderRadius: '0.5rem', border: 'none', background: '#14162B', color: 'white', fontWeight: '600', cursor: 'pointer' }}
        >
          {loading ? '...' : mode === 'signin' ? 'Se connecter' : "S'inscrire"}
        </button>

        <button
          type="button"
          onClick={() => setMode(mode === 'signin' ? 'signup' : 'signin')}
          style={{ background: 'none', border: 'none', color: '#1FA97F', fontSize: '0.85rem', cursor: 'pointer' }}
        >
          {mode === 'signin' ? "Pas encore de compte ? S'inscrire" : 'Déjà un compte ? Se connecter'}
        </button>
      </form>

      <a
        href="/confidentialite"
        target="_blank"
        rel="noopener noreferrer"
        style={{ marginTop: '1.5rem', fontSize: '0.75rem', color: '#999', textDecoration: 'underline' }}
      >
        Confidentialité & Mentions légales
      </a>
    </div>
  )
}
